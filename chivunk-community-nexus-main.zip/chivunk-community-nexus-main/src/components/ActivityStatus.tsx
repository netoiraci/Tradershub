
import { Circle } from 'lucide-react';

interface ActivityStatusProps {
  status: 'online' | 'away' | 'busy' | 'offline';
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const statusConfig = {
  online: { color: 'bg-green-400', text: 'Online', textColor: 'text-green-400' },
  away: { color: 'bg-yellow-400', text: 'Ausente', textColor: 'text-yellow-400' },
  busy: { color: 'bg-red-400', text: 'Ocupado', textColor: 'text-red-400' },
  offline: { color: 'bg-gray-400', text: 'Offline', textColor: 'text-gray-400' }
};

const sizeConfig = {
  sm: 'w-2 h-2',
  md: 'w-3 h-3',
  lg: 'w-4 h-4'
};

export function ActivityStatus({ status, showText = false, size = 'md' }: ActivityStatusProps) {
  const config = statusConfig[status];
  
  return (
    <div className="flex items-center space-x-2">
      <div className={`${sizeConfig[size]} ${config.color} rounded-full`} />
      {showText && (
        <span className={`text-sm ${config.textColor}`}>
          {config.text}
        </span>
      )}
    </div>
  );
}
