
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useAdminPanel } from '@/hooks/useAdminPanel';
import { AdminStats } from './admin/AdminStats';
import { PendingUsersTab } from './admin/PendingUsersTab';
import { UserManagementTab } from './admin/UserManagementTab';
import { AdminLogsTab } from './admin/AdminLogsTab';

export function AdminPanel() {
  const { user } = useAuth();
  const [selectedTab, setSelectedTab] = useState('pending');

  const {
    // Data
    pendingUsers,
    allUsers,
    adminLogs,
    stats,
    
    // Loading states
    loadingUsers,
    loadingAllUsers,
    loadingLogs,
    
    // Filters
    searchTerm,
    setSearchTerm,
    statusFilter,
    setStatusFilter,
    
    // Mutations
    approveUserMutation,
    rejectUserMutation,
    promoteUserMutation,
    demoteUserMutation,
    createUserMutation,
    editUserMutation,
  } = useAdminPanel();

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Estatísticas */}
      <AdminStats stats={stats} />

      {/* Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-3 bg-[rgb(var(--community-card))] border border-[rgb(var(--community-border))]">
          <TabsTrigger value="pending" className="relative data-[state=active]:bg-[rgb(var(--community-accent))] data-[state=active]:text-white">
            Usuários Pendentes
            {(stats?.pending || 0) > 0 && (
              <Badge variant="destructive" className="ml-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-red-500 text-white">
                {stats?.pending}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="users" className="data-[state=active]:bg-[rgb(var(--community-accent))] data-[state=active]:text-white">Gerenciar Usuários</TabsTrigger>
          <TabsTrigger value="logs" className="data-[state=active]:bg-[rgb(var(--community-accent))] data-[state=active]:text-white">Logs Administrativos</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-4">
          <PendingUsersTab
            pendingUsers={pendingUsers}
            loadingUsers={loadingUsers}
            onApproveUser={(userId) => approveUserMutation.mutate(userId)}
            onRejectUser={(userId, reason) => rejectUserMutation.mutate({ userId, reason })}
            approvePending={approveUserMutation.isPending}
            rejectPending={rejectUserMutation.isPending}
          />
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <UserManagementTab
            allUsers={allUsers}
            loadingAllUsers={loadingAllUsers}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            statusFilter={statusFilter}
            setStatusFilter={setStatusFilter}
            onCreateUser={(data) => createUserMutation.mutate(data)}
            onEditUser={(userId, data) => editUserMutation.mutate({ userId, formData: data })}
            onPromoteUser={(userId) => promoteUserMutation.mutate(userId)}
            onDemoteUser={(userId) => demoteUserMutation.mutate(userId)}
            createUserPending={createUserMutation.isPending}
            editUserPending={editUserMutation.isPending}
            promotePending={promoteUserMutation.isPending}
            demotePending={demoteUserMutation.isPending}
            currentUserId={user?.id}
          />
        </TabsContent>

        <TabsContent value="logs" className="space-y-4">
          <AdminLogsTab
            adminLogs={adminLogs}
            loadingLogs={loadingLogs}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
