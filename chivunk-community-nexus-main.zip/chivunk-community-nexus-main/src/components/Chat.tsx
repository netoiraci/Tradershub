
import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Send, Hash, Users } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useChatMessages, useSendMessage, useChatRealtime } from '@/hooks/useChat';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface ChatProps {
  roomId: string;
  roomName: string;
}

export function Chat({ roomId, roomName }: ChatProps) {
  const [message, setMessage] = useState('');
  const { user } = useAuth();
  const { data: messages = [], isLoading } = useChatMessages(roomId);
  const sendMessage = useSendMessage();
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Ativar realtime para esta sala
  useChatRealtime(roomId);

  // Auto scroll para a última mensagem
  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !user) return;

    sendMessage.mutate({
      roomId,
      content: message.trim()
    }, {
      onSuccess: () => {
        setMessage('');
      }
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full community-card border-community-border">
        <div className="text-center">
          <div className="w-8 h-8 bg-community-accent rounded-lg animate-pulse mx-auto mb-3"></div>
          <p className="text-community-secondary">Carregando mensagens...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full community-card border-community-border overflow-hidden">
      {/* Header da Sala */}
      <div className="flex items-center justify-between p-4 border-b border-community-border bg-community-card-hover">
        <div className="flex items-center space-x-3">
          <Hash className="w-5 h-5 text-community-muted" />
          <h3 className="font-semibold text-community-primary text-lg">{roomName}</h3>
        </div>
        <div className="flex items-center space-x-2 text-community-secondary text-sm">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span>Ao vivo</span>
        </div>
      </div>

      {/* Área de Mensagens */}
      <ScrollArea ref={scrollAreaRef} className="flex-1 p-4">
        {messages.length === 0 ? (
          <div className="text-center text-community-secondary py-12">
            <Hash className="w-16 h-16 mx-auto mb-4 opacity-30" />
            <h4 className="text-lg font-medium text-community-primary mb-2">
              Bem-vindo ao #{roomName}
            </h4>
            <p className="text-sm mb-1">Este é o início da sua conversa em #{roomName}.</p>
            <p className="text-sm">Seja o primeiro a enviar uma mensagem!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((msg, index) => {
              const authorName = msg.profiles?.name || 'Usuário';
              const timeAgo = formatDistanceToNow(new Date(msg.created_at), { 
                addSuffix: true,
                locale: ptBR 
              });
              const isOwnMessage = user?.id === msg.user_id;
              const prevMessage = messages[index - 1];
              const showAvatar = !prevMessage || prevMessage.user_id !== msg.user_id;

              return (
                <div
                  key={msg.id}
                  className={`flex space-x-3 hover:bg-community-card-hover -mx-2 px-2 py-1 rounded group ${
                    isOwnMessage ? 'bg-community-card-hover/50' : ''
                  }`}
                >
                  <div className="w-10 flex-shrink-0">
                    {showAvatar ? (
                      <Avatar className="w-10 h-10">
                        <AvatarImage src="" />
                        <AvatarFallback className="bg-community-accent text-white text-sm">
                          {authorName.split(' ').map(n => n[0]).join('').slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                    ) : (
                      <div className="w-10 h-10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-xs text-community-muted">
                          {new Date(msg.created_at).toLocaleTimeString('pt-BR', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    {showAvatar && (
                      <div className="flex items-baseline space-x-2 mb-1">
                        <span className="text-sm font-semibold text-community-primary hover:underline cursor-pointer">
                          {authorName}
                        </span>
                        <span className="text-xs text-community-muted">
                          {new Date(msg.created_at).toLocaleDateString('pt-BR')} às {new Date(msg.created_at).toLocaleTimeString('pt-BR', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </span>
                      </div>
                    )}
                    
                    <div className="text-sm text-community-text leading-relaxed">
                      {msg.content}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </ScrollArea>

      {/* Input de Mensagem */}
      {user && (
        <div className="p-4 border-t border-community-border">
          <form onSubmit={handleSendMessage}>
            <div className="flex space-x-3">
              <div className="flex-1 relative">
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={`Mensagem #${roomName.toLowerCase()}`}
                  className="input-community rounded-lg pr-12"
                  disabled={sendMessage.isPending}
                />
                <Button
                  type="submit"
                  size="sm"
                  disabled={sendMessage.isPending || !message.trim()}
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-community-accent hover:bg-community-accent/90 text-white p-2 h-8 w-8"
                >
                  <Send className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
