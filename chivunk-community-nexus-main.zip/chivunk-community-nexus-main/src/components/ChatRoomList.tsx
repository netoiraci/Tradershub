
import React from 'react';
import { Button } from '@/components/ui/button';
import { Hash, Users, Lock, Volume2, VolumeX } from 'lucide-react';
import { useChatRooms, useJoinRoom } from '@/hooks/useChat';
import { useAuth } from '@/contexts/AuthContext';

interface ChatRoomListProps {
  selectedRoomId?: string;
  onRoomSelect: (roomId: string, roomName: string) => void;
}

export function ChatRoomList({ selectedRoomId, onRoomSelect }: ChatRoomListProps) {
  const { user } = useAuth();
  const { data: rooms = [], isLoading } = useChatRooms();
  const joinRoom = useJoinRoom();

  const handleJoinRoom = async (roomId: string, roomName: string) => {
    if (!user) return;

    try {
      await joinRoom.mutateAsync({ roomId });
      onRoomSelect(roomId, roomName);
    } catch (error) {
      // Se o erro for de duplicação, significa que já está na sala
      if (error instanceof Error && error.message.includes('duplicate')) {
        onRoomSelect(roomId, roomName);
      }
    }
  };

  if (isLoading) {
    return (
      <div className="p-4">
        <div className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-8 bg-community-card-hover rounded animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-community-border">
        <h3 className="text-sm font-semibold text-community-primary uppercase tracking-wide">
          Trading Community
        </h3>
      </div>

      {/* Canais de Texto */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-3">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-xs font-semibold text-community-muted uppercase tracking-wide flex items-center">
              <Hash className="w-3 h-3 mr-1" />
              Canais de Texto
            </h4>
          </div>
          
          <div className="space-y-1">
            {rooms.map((room) => (
              <Button
                key={room.id}
                variant="ghost"
                onClick={() => handleJoinRoom(room.id, room.name)}
                className={`w-full justify-start px-2 py-1.5 h-auto rounded text-left transition-all ${
                  selectedRoomId === room.id
                    ? 'bg-community-accent text-white'
                    : 'text-community-secondary hover:text-community-primary hover:bg-community-card-hover'
                }`}
              >
                <div className="flex items-center space-x-2 w-full">
                  <div className="flex-shrink-0">
                    {room.is_public ? (
                      <Hash className="w-4 h-4" />
                    ) : (
                      <Lock className="w-4 h-4" />
                    )}
                  </div>
                  
                  <span className="flex-1 text-sm font-medium truncate">
                    {room.name}
                  </span>
                </div>
              </Button>
            ))}
          </div>
          
          {rooms.length === 0 && (
            <div className="text-center text-community-secondary py-8">
              <Hash className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-xs">Nenhum canal disponível</p>
            </div>
          )}
        </div>

        {/* Canais de Voz (placeholder) */}
        <div className="p-3 border-t border-community-border">
          <div className="flex items-center justify-between mb-2">
            <h4 className="text-xs font-semibold text-community-muted uppercase tracking-wide flex items-center">
              <Volume2 className="w-3 h-3 mr-1" />
              Canais de Voz
            </h4>
          </div>
          
          <div className="space-y-1">
            <Button
              variant="ghost"
              className="w-full justify-start px-2 py-1.5 h-auto rounded text-community-secondary hover:text-community-primary hover:bg-community-card-hover"
              disabled
            >
              <div className="flex items-center space-x-2 w-full">
                <Volume2 className="w-4 h-4 flex-shrink-0" />
                <span className="flex-1 text-sm font-medium truncate">
                  Sala Geral
                </span>
              </div>
            </Button>
            
            <Button
              variant="ghost"
              className="w-full justify-start px-2 py-1.5 h-auto rounded text-community-secondary hover:text-community-primary hover:bg-community-card-hover"
              disabled
            >
              <div className="flex items-center space-x-2 w-full">
                <Volume2 className="w-4 h-4 flex-shrink-0" />
                <span className="flex-1 text-sm font-medium truncate">
                  Trading Room
                </span>
              </div>
            </Button>
          </div>
          
          <p className="text-xs text-community-muted mt-2 opacity-60">
            Em breve
          </p>
        </div>
      </div>
    </div>
  );
}
