
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Heart, MessageCircle, MoreHorizontal, Trash2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useComments, useCreateComment, useDeleteComment, Comment } from '@/hooks/useThreadedComments';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface CommentThreadProps {
  postId: string;
  className?: string;
}

type CommentWithChildren = Comment & { children: CommentWithChildren[] };

interface CommentItemProps {
  comment: CommentWithChildren;
  postId: string;
  onReply: (parentId: string) => void;
  level?: number;
}

function CommentItem({ comment, postId, onReply, level = 0 }: CommentItemProps) {
  const { user } = useAuth();
  const deleteComment = useDeleteComment();
  const [showActions, setShowActions] = useState(false);
  
  const timeAgo = formatDistanceToNow(new Date(comment.created_at), { 
    addSuffix: true,
    locale: ptBR 
  });

  const authorName = comment.profiles?.name || 'Usuário';
  const isAuthor = user?.id === comment.author_id;
  const indentLevel = Math.min(level, 3); // Max 3 levels of indentation

  const handleDelete = () => {
    if (window.confirm('Tem certeza que deseja excluir este comentário?')) {
      deleteComment.mutate({ commentId: comment.id, postId });
    }
  };

  return (
    <div 
      className={`flex space-x-3 ${indentLevel > 0 ? 'ml-8 pl-4 border-l border-[#2C2C2C]' : ''}`}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      <Avatar className="w-8 h-8 flex-shrink-0">
        <AvatarImage src="" />
        <AvatarFallback className="bg-[#4B4B4B] text-white text-xs">
          {authorName.split(' ').map(n => n[0]).join('').slice(0, 2)}
        </AvatarFallback>
      </Avatar>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center space-x-2 mb-1">
          <span className="text-sm font-medium text-[#FFFFFF]">{authorName}</span>
          <span className="text-xs text-[#A3A3A3]">{timeAgo}</span>
        </div>
        
        <div className="text-sm text-[#A3A3A3] mb-2 leading-relaxed">
          {comment.content}
        </div>
        
        <div className={`flex items-center space-x-4 transition-opacity duration-200 ${showActions ? 'opacity-100' : 'opacity-60'}`}>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onReply(comment.id)}
            className="h-auto p-1 text-xs text-[#A3A3A3] hover:text-white"
          >
            <MessageCircle className="w-3 h-3 mr-1" />
            Responder
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            className="h-auto p-1 text-xs text-[#A3A3A3] hover:text-red-400"
          >
            <Heart className="w-3 h-3 mr-1" />
            Curtir
          </Button>
          
          {isAuthor && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDelete}
              disabled={deleteComment.isPending}
              className="h-auto p-1 text-xs text-[#A3A3A3] hover:text-red-400"
            >
              <Trash2 className="w-3 h-3 mr-1" />
              Excluir
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

interface CommentFormProps {
  postId: string;
  parentId?: string;
  onCancel?: () => void;
  placeholder?: string;
  autoFocus?: boolean;
}

function CommentForm({ postId, parentId, onCancel, placeholder = "Escreva um comentário...", autoFocus = false }: CommentFormProps) {
  const [content, setContent] = useState('');
  const { user } = useAuth();
  const createComment = useCreateComment();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() || !user) return;

    createComment.mutate({
      postId,
      parentId,
      content: content.trim()
    }, {
      onSuccess: () => {
        setContent('');
        onCancel?.();
      }
    });
  };

  if (!user) return null;

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <Textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder={placeholder}
        rows={3}
        autoFocus={autoFocus}
        className="resize-none border-[#2C2C2C] bg-[#1E1E1E] text-white placeholder:text-[#A3A3A3] text-sm focus:ring-2 focus:ring-[#4B4B4B]/20"
      />
      <div className="flex items-center justify-end space-x-2">
        {onCancel && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={onCancel}
            className="text-[#A3A3A3] hover:text-white"
          >
            Cancelar
          </Button>
        )}
        <Button
          type="submit"
          size="sm"
          disabled={createComment.isPending || !content.trim()}
          className="bg-[#4B4B4B] hover:bg-[#5A5A5A] text-white"
        >
          {createComment.isPending ? 'Postando...' : 'Comentar'}
        </Button>
      </div>
    </form>
  );
}

export function CommentThread({ postId, className = '' }: CommentThreadProps) {
  const { data: comments = [], isLoading } = useComments(postId);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);

  // Build threaded structure
  const buildCommentTree = (comments: Comment[]): CommentWithChildren[] => {
    const commentMap = new Map<string, CommentWithChildren>();
    const rootComments: CommentWithChildren[] = [];

    // Initialize all comments with empty children array
    comments.forEach(comment => {
      commentMap.set(comment.id, { ...comment, children: [] });
    });

    // Build the tree structure
    comments.forEach(comment => {
      const commentWithChildren = commentMap.get(comment.id)!;
      
      if (comment.parent_id) {
        const parent = commentMap.get(comment.parent_id);
        if (parent) {
          parent.children.push(commentWithChildren);
        } else {
          // Parent doesn't exist (maybe deleted), treat as root comment
          rootComments.push(commentWithChildren);
        }
      } else {
        rootComments.push(commentWithChildren);
      }
    });

    return rootComments;
  };

  const renderComment = (comment: CommentWithChildren, level = 0): React.ReactNode => {
    return (
      <div key={comment.id} className="space-y-4">
        <CommentItem
          comment={comment}
          postId={postId}
          onReply={setReplyingTo}
          level={level}
        />
        
        {replyingTo === comment.id && (
          <div className={level > 0 ? 'ml-8 pl-4' : 'ml-11'}>
            <CommentForm
              postId={postId}
              parentId={comment.id}
              onCancel={() => setReplyingTo(null)}
              placeholder={`Respondendo para ${comment.profiles?.name || 'Usuário'}...`}
              autoFocus
            />
          </div>
        )}
        
        {comment.children.length > 0 && (
          <div className="space-y-4">
            {comment.children.map(child => renderComment(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  const commentTree = buildCommentTree(comments);

  if (isLoading) {
    return (
      <div className={`space-y-4 ${className}`}>
        <div className="text-center text-[#A3A3A3] py-4">
          Carregando comentários...
        </div>
      </div>
    );
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Main comment form */}
      <CommentForm postId={postId} />
      
      {/* Comments list */}
      {commentTree.length === 0 ? (
        <div className="text-center text-[#A3A3A3] py-8">
          <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Ainda não há comentários.</p>
          <p className="text-sm">Seja o primeiro a comentar!</p>
        </div>
      ) : (
        <div className="space-y-6">
          {commentTree.map(comment => renderComment(comment))}
        </div>
      )}
    </div>
  );
}
