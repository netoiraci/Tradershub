
import { ReactNode } from 'react';
import { CommunitySidebar } from './CommunitySidebar';
import { NotificationBell } from './NotificationBell';
import { useAuth } from '@/contexts/AuthContext';
import { Navigate } from 'react-router-dom';

interface CommunityLayoutProps {
  children: ReactNode;
}

export function CommunityLayout({ children }: CommunityLayoutProps) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="community-layout flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-[rgb(var(--community-accent))] rounded-xl flex items-center justify-center mb-4 mx-auto animate-pulse">
            <span className="text-white font-bold text-xl">C</span>
          </div>
          <p className="text-community-primary font-semibold">Loading community...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  return (
    <div className="community-layout">
      <CommunitySidebar />
      <main className="lg:ml-64 min-h-screen">
        <div className="px-4 py-4 max-w-none mx-auto">
          {/* Header with notifications */}
          <div className="flex justify-end mb-4">
            <NotificationBell />
          </div>
          {children}
        </div>
      </main>
    </div>
  );
}
