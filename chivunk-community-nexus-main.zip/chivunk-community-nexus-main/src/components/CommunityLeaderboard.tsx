
import { Trophy, Crown, Star, TrendingUp } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { ActivityStatus } from './ActivityStatus';
import { UserLevel } from './UserLevel';
import { DiscordBadges } from './DiscordBadges';

interface LeaderboardUser {
  id: string;
  name: string;
  posts_count: number;
  likes_received: number;
}

export function CommunityLeaderboard() {
  const { data: topUsers = [], isLoading } = useQuery({
    queryKey: ['leaderboard'],
    queryFn: async () => {
      // First get profiles with basic info
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, name')
        .limit(10);

      if (profilesError) throw profilesError;

      if (!profiles || profiles.length === 0) {
        return [];
      }

      // Get posts count for each user
      const leaderboardData = await Promise.all(
        profiles.map(async (profile) => {
          // Count posts for this user
          const { count: postsCount } = await supabase
            .from('posts')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', profile.id);

          // Get total likes received across all posts
          const { data: postsWithLikes } = await supabase
            .from('posts')
            .select('likes_count')
            .eq('user_id', profile.id);

          const totalLikes = postsWithLikes?.reduce((sum, post) => sum + (post.likes_count || 0), 0) || 0;

          return {
            id: profile.id,
            name: profile.name || 'Usuário',
            posts_count: postsCount || 0,
            likes_received: totalLikes
          };
        })
      );

      // Sort by posts count descending and take top 5
      return leaderboardData
        .sort((a, b) => b.posts_count - a.posts_count)
        .slice(0, 5);
    }
  });

  return (
    <Card className="community-card">
      <CardContent className="p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-8 h-8 bg-[rgb(var(--community-accent))] rounded-lg flex items-center justify-center">
            <Trophy className="w-4 h-4 text-white" />
          </div>
          <h3 className="text-lg font-semibold text-community-primary">Top Membros</h3>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-16 bg-[rgb(var(--community-card))] rounded-xl"></div>
              </div>
            ))}
          </div>
        ) : topUsers.length === 0 ? (
          <div className="text-center py-8">
            <Trophy className="w-12 h-12 text-[rgb(var(--community-border))] mx-auto mb-3" />
            <p className="text-community-secondary">
              Seja o primeiro a participar e aparecer no ranking!
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {topUsers.map((user, index) => (
              <div
                key={user.id}
                className={`p-4 rounded-xl border transition-all duration-200 ${
                  index === 0
                    ? 'border-yellow-400 bg-gradient-to-r from-yellow-400/10 to-transparent'
                    : index === 1
                    ? 'border-gray-300 bg-gradient-to-r from-gray-300/10 to-transparent'
                    : index === 2
                    ? 'border-orange-400 bg-gradient-to-r from-orange-400/10 to-transparent'
                    : 'border-[rgb(var(--community-border))] bg-[rgb(var(--community-card))]'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold ${
                        index === 0 ? 'bg-yellow-500' :
                        index === 1 ? 'bg-gray-400' :
                        index === 2 ? 'bg-orange-500' :
                        'bg-[rgb(var(--community-accent))]'
                      }`}>
                        {index < 3 ? (
                          index === 0 ? <Crown className="w-5 h-5" /> : 
                          index === 1 ? <Star className="w-5 h-5" /> :
                          <TrendingUp className="w-5 h-5" />
                        ) : (
                          index + 1
                        )}
                      </div>
                      <div className="absolute -bottom-1 -right-1">
                        <ActivityStatus status="online" size="sm" />
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-community-primary">{user.name}</h4>
                      <div className="flex items-center space-x-2 text-sm text-community-secondary">
                        <span>Nível {Math.floor(user.posts_count / 5) + 1}</span>
                        <span>•</span>
                        <span>{user.posts_count * 10} XP</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-sm font-medium text-community-primary">{user.posts_count} posts</div>
                    <div className="text-xs text-community-secondary">{user.likes_received} curtidas</div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <DiscordBadges userId={user.id} compact />
                  <UserLevel 
                    level={Math.floor(user.posts_count / 5) + 1} 
                    xp={(user.posts_count * 10) % 100} 
                    xpToNext={100 - ((user.posts_count * 10) % 100)} 
                    compact 
                  />
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-6 pt-4 border-t border-[rgb(var(--community-border))]">
          <div className="text-center">
            <p className="text-sm text-community-secondary mb-2">
              Participe e apareça no ranking!
            </p>
            <div className="bg-[rgb(var(--community-card))] rounded-lg p-3">
              <span className="text-sm text-community-secondary">Comece postando e interagindo</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
