
import { useState } from 'react';
import { 
  Home, 
  Users, 
  TrendingUp,
  Target,
  BarChart3,
  BookOpen,
  Lightbulb,
  Calendar,
  Video,
  MessageSquare
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useIsAdmin } from "@/hooks/useIsAdmin";
import { PresentationModal } from './PresentationModal';
import { MobileMenuButton } from './sidebar/MobileMenuButton';
import { SearchBar } from './sidebar/SearchBar';
import { NavigationSection } from './sidebar/NavigationSection';
import { AdminSection } from './sidebar/AdminSection';
import { UserProfile } from './sidebar/UserProfile';
import { SidebarHeader } from './sidebar/SidebarHeader';

// Navegação principal
const mainNavigation = [
  { name: 'Home', href: '/', icon: Home },
  { name: 'Apresentações', href: '/introducoes', icon: Users, highlight: true },
  { name: 'Chat da Comunidade', href: '/chat', icon: MessageSquare, highlight: true },
];

const tradingSpaces = [
  { name: 'Análise Técnica', href: '/analise-tecnica', icon: BarChart3 },
  { name: 'Estratégias de Trading', href: '/estrategias', icon: Target },
  { name: 'Análises de Mercado', href: '/analise', icon: TrendingUp },
  { name: 'Histórias & Cases', href: '/historias', icon: BookOpen },
  { name: 'Ideias e Sugestões', href: '/ideias', icon: Lightbulb },
  { name: 'Networking', href: '/networking', icon: Users },
  { name: 'Discussões Gerais', href: '/discussoes', icon: MessageSquare },
];

const communityFeatures = [
  { name: 'Agenda de Eventos', href: '/agenda', icon: Calendar },
  { name: 'Videochamadas', href: '/videochamadas', icon: Video },
];

export function CommunitySidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showPresentationModal, setShowPresentationModal] = useState(false);
  const { user } = useAuth();
  const { data: isAdmin = false } = useIsAdmin();

  return (
    <>
      {/* Mobile menu button */}
      <MobileMenuButton 
        isCollapsed={isCollapsed}
        onToggle={() => setIsCollapsed(!isCollapsed)}
      />

      {/* Sidebar */}
      <div className={`
        fixed left-0 top-0 h-full community-sidebar z-40
        transition-transform duration-300 ease-in-out
        ${isCollapsed ? '-translate-x-full lg:translate-x-0' : 'translate-x-0'}
        w-64
      `}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <SidebarHeader />

          {/* Search */}
          <SearchBar 
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
          />

          {/* Navigation */}
          <nav className="flex-1 px-4 space-y-4 overflow-y-auto">
            {/* Main Navigation */}
            <NavigationSection
              title="Principal"
              items={mainNavigation}
              searchTerm={searchTerm}
            />

            {/* Trading Spaces */}
            <NavigationSection
              title="Espaços de Trading"
              items={tradingSpaces}
              searchTerm={searchTerm}
            />

            {/* Community Features */}
            <NavigationSection
              title="Recursos"
              items={communityFeatures}
              searchTerm={searchTerm}
            />

            {/* Admin Section */}
            <AdminSection isAdmin={isAdmin} />
          </nav>

          {/* User Profile */}
          {user && <UserProfile user={user} />}
        </div>
      </div>

      {/* Presentation Modal */}
      <PresentationModal
        isOpen={showPresentationModal}
        onClose={() => setShowPresentationModal(false)}
      />
    </>
  );
}
