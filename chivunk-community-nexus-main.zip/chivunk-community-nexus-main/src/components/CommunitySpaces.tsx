
import { NavLink } from 'react-router-dom';
import { 
  TrendingUp, 
  Target, 
  BarChart3, 
  BookOpen, 
  Lightbulb, 
  Users,
  MessageSquare,
  Calendar,
  Video
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

const communitySpaces = [
  {
    name: 'Análise Técnica',
    href: '/analise-tecnica',
    icon: BarChart3,
    description: 'Análises de gráficos, indicadores e padrões',
    section: 'analise-tecnica'
  },
  {
    name: 'Estratégias de Trading',
    href: '/estrategias',
    icon: Target,
    description: 'Setups, métodos e sistemas de trading',
    section: 'estrategias'
  },
  {
    name: 'Análises de Mercado',
    href: '/analise',
    icon: TrendingUp,
    description: 'Notícias, fundamentalista e sentimento',
    section: 'analise'
  },
  {
    name: 'Histórias & Cases',
    href: '/historias',
    icon: BookOpen,
    description: 'Experiências, cases de sucesso e lições',
    section: 'historias'
  },
  {
    name: 'Ideias e Sugestões',
    href: '/ideias',
    icon: Lightbulb,
    description: 'Brainstorming e novas perspectivas',
    section: 'ideias'
  },
  {
    name: 'Networking',
    href: '/networking',
    icon: Users,
    description: 'Conecte-se com outros traders',
    section: 'networking'
  },
  {
    name: 'Discussões Gerais',
    href: '/discussoes',
    icon: MessageSquare,
    description: 'Discussões gerais sobre trading e mercados',
    section: 'discussoes'
  },
  {
    name: 'Apresentações',
    href: '/introducoes',
    icon: Users,
    description: 'Se apresente para a comunidade',
    section: 'introducoes',
    highlight: true
  },
  {
    name: 'Agenda de Eventos',
    href: '/agenda',
    icon: Calendar,
    description: 'Webinars, lives e encontros',
    section: 'agenda'
  },
  {
    name: 'Videochamadas',
    href: '/videochamadas',
    icon: Video,
    description: 'Salas de estudo e discussão ao vivo',
    section: 'videochamadas'
  }
];

export function CommunitySpaces() {
  // Buscar contagem de posts por seção
  const { data: postCounts } = useQuery({
    queryKey: ['post-counts-by-section'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('posts')
        .select('section');
      
      if (error) throw error;
      
      // Contar posts por seção
      const counts: Record<string, number> = {};
      data?.forEach(post => {
        counts[post.section] = (counts[post.section] || 0) + 1;
      });
      
      return counts;
    }
  });

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-community-primary mb-4">Espaços da Comunidade</h3>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {communitySpaces.map((space) => {
          const postCount = postCounts?.[space.section] || 0;
          
          return (
            <NavLink
              key={space.href}
              to={space.href}
              className={({ isActive }) => `
                community-card community-card-hover p-4 block transition-all duration-200
                ${isActive ? 'border-[rgb(var(--community-accent))] bg-[rgb(var(--community-card-hover))]' : ''}
                ${space.highlight ? 'border-2 border-[rgb(var(--community-accent))]/50' : ''}
              `}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    space.highlight 
                      ? 'bg-[rgb(var(--community-accent))]' 
                      : 'bg-[rgb(var(--community-card-hover))]'
                  }`}>
                    <space.icon className={`w-6 h-6 ${
                      space.highlight ? 'text-white' : 'text-[rgb(var(--community-accent))]'
                    }`} />
                  </div>
                  <div>
                    <h4 className="font-medium text-community-primary">{space.name}</h4>
                    <p className="text-sm text-community-secondary">{space.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-sm font-medium text-[rgb(var(--community-accent))]">
                    {postCount}
                  </span>
                  <p className="text-xs text-community-secondary">posts</p>
                </div>
              </div>
            </NavLink>
          );
        })}
      </div>
    </div>
  );
}
