
import { TrendingUp, Users, MessageSquare, Target } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export function CommunityStats() {
  // Buscar estatísticas reais do banco de dados
  const { data: stats, isLoading } = useQuery({
    queryKey: ['community-stats'],
    queryFn: async () => {
      // Contar usuários únicos que fizeram posts
      const { count: activeMembers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      // Contar posts de hoje
      const today = new Date().toISOString().split('T')[0];
      const { count: todayPosts } = await supabase
        .from('posts')
        .select('*', { count: 'exact', head: true })
        .gte('created_at', today);

      // Contar total de posts
      const { count: totalPosts } = await supabase
        .from('posts')
        .select('*', { count: 'exact', head: true });

      return {
        activeMembers: activeMembers || 0,
        todayPosts: todayPosts || 0,
        totalPosts: totalPosts || 0,
        activeChallenges: 0 // Por enquanto 0, será implementado futuramente
      };
    }
  });

  const displayStats = [
    {
      label: 'Membros Cadastrados',
      value: isLoading ? '...' : stats?.activeMembers.toString() || '0',
      change: '+0%',
      icon: Users,
      trend: 'stable'
    },
    {
      label: 'Posts Hoje',
      value: isLoading ? '...' : stats?.todayPosts.toString() || '0',
      change: '+0%',
      icon: MessageSquare,
      trend: 'stable'
    },
    {
      label: 'Total de Posts',
      value: isLoading ? '...' : stats?.totalPosts.toString() || '0',
      change: '+0%',
      icon: TrendingUp,
      trend: 'stable'
    },
    {
      label: 'Desafios Ativos',
      value: stats?.activeChallenges.toString() || '0',
      change: '0%',
      icon: Target,
      trend: 'stable'
    }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
      {displayStats.map((stat) => (
        <Card key={stat.label} className="community-card">
          <CardContent className="p-3">
            <div className="flex items-center justify-between mb-2">
              <stat.icon className="w-4 h-4 text-white" />
              <span className={`text-xs font-medium ${
                stat.trend === 'up' 
                  ? 'text-green-400' 
                  : stat.trend === 'down' 
                  ? 'text-red-400' 
                  : 'text-community-secondary'
              }`}>
                {stat.change}
              </span>
            </div>
            <div className="text-xl font-bold text-community-primary mb-1">
              {stat.value}
            </div>
            <div className="text-xs text-community-secondary">
              {stat.label}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
