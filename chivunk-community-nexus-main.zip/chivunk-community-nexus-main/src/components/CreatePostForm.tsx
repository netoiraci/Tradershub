
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/AuthContext';
import { useCreatePost } from '@/hooks/usePosts';

interface CreatePostFormProps {
  section: string;
  onPostCreated?: () => void;
  placeholder?: string;
}

export function CreatePostForm({ section, onPostCreated, placeholder = "Comece uma discussão..." }: CreatePostFormProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const { user } = useAuth();
  const createPost = useCreatePost();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !title.trim() || !content.trim()) return;

    console.log('Submitting post:', { title, content, section });

    createPost.mutate({
      title: title.trim(),
      content: content.trim(),
      section,
      category: section === 'Feed Principal' ? 'Discussão' : 'Apresentação'
    }, {
      onSuccess: () => {
        setTitle('');
        setContent('');
        onPostCreated?.();
      }
    });
  };

  if (!user) return null;

  const userName = user.user_metadata?.name || user.email?.split('@')[0] || 'Trader';

  return (
    <Card className="community-card mb-8 fade-in-community">
      <CardContent className="p-8">
        <div className="flex items-start space-x-4 mb-4">
          <Avatar className="w-10 h-10 flex-shrink-0">
            <AvatarImage src="" />
            <AvatarFallback className="bg-[rgb(var(--community-accent))] text-white text-sm font-medium">
              {userName[0].toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-community-primary">
              {userName}
            </p>
            <p className="text-xs text-community-muted">{section}</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Título do seu post..."
            className="input-community border-[rgb(var(--community-border))] bg-[rgb(var(--community-bg))] text-community-primary placeholder:text-community-muted"
          />
          
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={placeholder}
            rows={4}
            className="input-community resize-none border-[rgb(var(--community-border))] bg-[rgb(var(--community-bg))] text-community-primary placeholder:text-community-muted text-base focus:ring-2 focus:ring-[rgb(var(--community-accent))]/20 whitespace-pre-wrap"
            style={{ whiteSpace: 'pre-wrap' }}
          />
          
          <div className="flex items-center justify-end pt-2">
            <Button
              type="submit"
              disabled={createPost.isPending || !title.trim() || !content.trim()}
              className="btn-community-primary disabled:opacity-50 px-8"
            >
              {createPost.isPending ? 'Postando...' : 'Postar'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
