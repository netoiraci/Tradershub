
import { Shield, Crown, Zap, Star, Heart, MessageSquare, TrendingUp, Target } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface DiscordBadge {
  id: string;
  name: string;
  icon: React.ComponentType<any>;
  color: string;
  description: string;
  earned: boolean;
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
}

const discordBadges: DiscordBadge[] = [
  {
    id: 'early-supporter',
    name: 'Apoiador Inicial',
    icon: Heart,
    color: 'text-pink-400',
    description: 'Membro desde o início da comunidade',
    earned: true,
    rarity: 'epic'
  },
  {
    id: 'active-member',
    name: 'Membro Ativo',
    icon: Zap,
    color: 'text-yellow-400',
    description: '30 dias consecutivos de atividade',
    earned: true,
    rarity: 'uncommon'
  },
  {
    id: 'helper',
    name: 'Mentor',
    icon: Shield,
    color: 'text-blue-400',
    description: 'Ajudou mais de 50 membros',
    earned: false,
    rarity: 'rare'
  },
  {
    id: 'analyst',
    name: 'Analista Expert',
    icon: TrendingUp,
    color: 'text-green-400',
    description: 'Análises sempre precisas',
    earned: false,
    rarity: 'epic'
  },
  {
    id: 'legend',
    name: 'Lenda',
    icon: Crown,
    color: 'text-purple-400',
    description: 'Reconhecimento da comunidade',
    earned: false,
    rarity: 'legendary'
  }
];

const rarityColors = {
  common: 'border-gray-400',
  uncommon: 'border-green-400',
  rare: 'border-blue-400',
  epic: 'border-purple-400',
  legendary: 'border-yellow-400'
};

interface DiscordBadgesProps {
  userId?: string;
  compact?: boolean;
}

export function DiscordBadges({ userId, compact = false }: DiscordBadgesProps) {
  const earnedBadges = discordBadges.filter(badge => badge.earned);

  if (compact) {
    return (
      <div className="flex items-center space-x-1">
        {earnedBadges.slice(0, 3).map((badge) => {
          const IconComponent = badge.icon;
          return (
            <div
              key={badge.id}
              className={`w-6 h-6 rounded-full border-2 ${rarityColors[badge.rarity]} bg-[rgb(var(--community-card))] flex items-center justify-center`}
              title={badge.name}
            >
              <IconComponent className={`w-3 h-3 ${badge.color}`} />
            </div>
          );
        })}
        {earnedBadges.length > 3 && (
          <Badge variant="outline" className="text-xs h-6 px-2">
            +{earnedBadges.length - 3}
          </Badge>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h4 className="font-medium text-community-primary flex items-center space-x-2">
        <Star className="w-4 h-4 text-[rgb(var(--community-accent))]" />
        <span>Badges Especiais</span>
      </h4>
      
      <div className="grid grid-cols-2 gap-3">
        {discordBadges.map((badge) => {
          const IconComponent = badge.icon;
          return (
            <div
              key={badge.id}
              className={`p-3 rounded-lg border-2 transition-all duration-200 ${
                badge.earned
                  ? `${rarityColors[badge.rarity]} bg-[rgb(var(--community-card))]`
                  : 'border-[rgb(var(--community-border))] bg-[rgb(var(--community-bg))] opacity-50'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  badge.earned 
                    ? 'bg-[rgb(var(--community-accent))]' 
                    : 'bg-[rgb(var(--community-border))]'
                }`}>
                  <IconComponent className={`w-4 h-4 ${
                    badge.earned ? 'text-white' : 'text-[rgb(var(--community-text-muted))]'
                  }`} />
                </div>
                <div className="flex-1 min-w-0">
                  <h5 className={`text-sm font-medium truncate ${
                    badge.earned ? 'text-community-primary' : 'text-community-secondary'
                  }`}>
                    {badge.name}
                  </h5>
                  <p className="text-xs text-community-secondary truncate">
                    {badge.description}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
