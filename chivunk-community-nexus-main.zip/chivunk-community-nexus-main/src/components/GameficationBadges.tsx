
import { Star, TrendingUp, MessageSquare, Target } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { UserLevel } from './UserLevel';
import { DiscordBadges } from './DiscordBadges';
import { ActivityStatus } from './ActivityStatus';
import { useAuth } from '@/contexts/AuthContext';

export function GameficationBadges() {
  const { user } = useAuth();

  if (!user) return null;

  // Dados reais baseados no usuário logado
  const userLevel = 1; // Começar do nível 1 para novos usuários
  const userXp = 0; // Começar com 0 XP
  const userName = user.user_metadata?.name || user.email?.split('@')[0] || 'Trader';

  return (
    <Card className="community-card">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-[rgb(var(--community-accent))] rounded-lg flex items-center justify-center">
              <Star className="w-4 h-4 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-community-primary">Seu Perfil</h3>
          </div>
          <ActivityStatus status="online" showText />
        </div>

        {/* User Level */}
        <div className="mb-6">
          <UserLevel 
            level={userLevel} 
            xp={userXp} 
            xpToNext={100} 
            username={userName}
          />
        </div>

        {/* Discord-style Badges */}
        <div className="mb-6">
          <DiscordBadges />
        </div>

        {/* Quick Stats - Começar com 0 */}
        <div className="bg-[rgb(var(--community-card))] rounded-xl p-4">
          <h4 className="font-medium text-community-primary mb-3">Estatísticas</h4>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-[rgb(var(--community-accent))]">0</div>
              <div className="text-xs text-community-secondary">Posts</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[rgb(var(--community-accent))]">0</div>
              <div className="text-xs text-community-secondary">Curtidas</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[rgb(var(--community-accent))]">0</div>
              <div className="text-xs text-community-secondary">Comentários</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[rgb(var(--community-accent))]">0</div>
              <div className="text-xs text-community-secondary">Conquistas</div>
            </div>
          </div>
        </div>

        {/* Next Challenge */}
        <div className="mt-6 p-4 bg-[rgb(var(--community-card))] rounded-xl border border-[rgb(var(--community-accent))]/30">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-community-primary">Primeiro Objetivo</h4>
              <p className="text-sm text-community-secondary">Complete sua apresentação</p>
            </div>
            <div className="flex items-center space-x-2">
              <Target className="w-5 h-5 text-[rgb(var(--community-accent))]" />
              <span className="text-sm font-medium text-community-primary">+25 XP</span>
            </div>
          </div>
          <div className="mt-3">
            <div className="w-full bg-[rgb(var(--community-bg))] rounded-full h-2">
              <div className="bg-[rgb(var(--community-accent))] h-2 rounded-full w-0" />
            </div>
            <div className="flex justify-between text-xs text-community-secondary mt-1">
              <span>0/1 apresentação</span>
              <span>Seja bem-vindo!</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
