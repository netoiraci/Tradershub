
import React from 'react';
import { ExternalLink, TrendingUp, BarChart3, Target, Calendar, Video } from 'lucide-react';

interface LinkifiedTextProps {
  text: string;
  section: string;
  className?: string;
}

const getSectionIcon = (section: string) => {
  const icons = {
    'analise-tecnica': BarChart3,
    'estrategias': Target,
    'analise': TrendingUp,
    'agenda': Calendar,
    'videochamadas': Video,
  };
  return icons[section as keyof typeof icons] || ExternalLink;
};

const getSectionLinkStyle = (section: string) => {
  const styles = {
    'analise-tecnica': 'text-blue-400 hover:text-blue-300 border-b border-blue-400/30 hover:border-blue-300/50',
    'estrategias': 'text-green-400 hover:text-green-300 border-b border-green-400/30 hover:border-green-300/50',
    'analise': 'text-yellow-400 hover:text-yellow-300 border-b border-yellow-400/30 hover:border-yellow-300/50',
    'historias': 'text-purple-400 hover:text-purple-300 border-b border-purple-400/30 hover:border-purple-300/50',
    'ideias': 'text-pink-400 hover:text-pink-300 border-b border-pink-400/30 hover:border-pink-300/50',
    'networking': 'text-orange-400 hover:text-orange-300 border-b border-orange-400/30 hover:border-orange-300/50',
    'discussoes': 'text-cyan-400 hover:text-cyan-300 border-b border-cyan-400/30 hover:border-cyan-300/50',
    'agenda': 'text-indigo-400 hover:text-indigo-300 border-b border-indigo-400/30 hover:border-indigo-300/50',
    'videochamadas': 'text-red-400 hover:text-red-300 border-b border-red-400/30 hover:border-red-300/50',
    'Feed Principal': 'text-[#4B4B4B] hover:text-white border-b border-[#4B4B4B]/30 hover:border-white/50',
    'Apresentações': 'text-[#4B4B4B] hover:text-white border-b border-[#4B4B4B]/30 hover:border-white/50'
  };
  return styles[section as keyof typeof styles] || 'text-[#4B4B4B] hover:text-white border-b border-[#4B4B4B]/30 hover:border-white/50';
};

export function LinkifiedText({ text, section, className = '' }: LinkifiedTextProps) {
  // Regex mais robusta para detectar URLs
  const urlRegex = /(https?:\/\/[^\s<>"{}|\\^`\[\]]+)/gi;
  
  const parts = text.split(urlRegex);
  const IconComponent = getSectionIcon(section);
  const linkStyle = getSectionLinkStyle(section);

  return (
    <span className={className}>
      {parts.map((part, index) => {
        if (part.match(urlRegex)) {
          // É uma URL
          return (
            <a
              key={index}
              href={part}
              target="_blank"
              rel="noopener noreferrer"
              className={`inline-flex items-center gap-1 transition-all duration-200 ${linkStyle}`}
              onClick={(e) => e.stopPropagation()}
            >
              <IconComponent className="w-3 h-3 flex-shrink-0" />
              <span className="break-all">{part}</span>
            </a>
          );
        } else {
          // É texto normal
          return <span key={index}>{part}</span>;
        }
      })}
    </span>
  );
}
