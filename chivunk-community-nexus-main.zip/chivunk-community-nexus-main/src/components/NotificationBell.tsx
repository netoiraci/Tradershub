
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Bell, Check, X, Crown, Shield, UserCheck, UserX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  read: boolean;
  created_at: string;
  data: any;
}

export function NotificationBell() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);

  // Buscar notificações do usuário
  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      return data as Notification[];
    },
    enabled: !!user
  });

  // Marcar notificação como lida
  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: string) => {
      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('id', notificationId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    }
  });

  // Marcar todas como lidas
  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      if (!user) return;
      
      const { error } = await supabase
        .from('notifications')
        .update({ read: true })
        .eq('user_id', user.id)
        .eq('read', false);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    }
  });

  // Remover notificação
  const removeNotificationMutation = useMutation({
    mutationFn: async (notificationId: string) => {
      const { error } = await supabase
        .from('notifications')
        .delete()
        .eq('id', notificationId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    }
  });

  const unreadCount = notifications.filter(n => !n.read).length;

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Agora';
    if (minutes < 60) return `${minutes}m`;
    if (hours < 24) return `${hours}h`;
    if (days < 7) return `${days}d`;
    return date.toLocaleDateString('pt-BR');
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'approval':
        return <UserCheck className="w-5 h-5 text-green-500" />;
      case 'rejection':
        return <UserX className="w-5 h-5 text-red-500" />;
      case 'promotion':
        return <Crown className="w-5 h-5 text-yellow-500" />;
      case 'demotion':
        return <Shield className="w-5 h-5 text-orange-500" />;
      default:
        return <Bell className="w-5 h-5 text-blue-500" />;
    }
  };

  const getNotificationStyle = (type: string, read: boolean) => {
    const baseStyle = `cursor-pointer transition-all duration-200 ${
      !read ? 'bg-blue-50 border-blue-200 shadow-sm' : 'hover:bg-gray-50'
    }`;
    
    switch (type) {
      case 'approval':
        return `${baseStyle} ${!read ? 'border-l-4 border-l-green-500' : ''}`;
      case 'rejection':
        return `${baseStyle} ${!read ? 'border-l-4 border-l-red-500' : ''}`;
      case 'promotion':
        return `${baseStyle} ${!read ? 'border-l-4 border-l-yellow-500' : ''}`;
      case 'demotion':
        return `${baseStyle} ${!read ? 'border-l-4 border-l-orange-500' : ''}`;
      default:
        return `${baseStyle} ${!read ? 'border-l-4 border-l-blue-500' : ''}`;
    }
  };

  // Agrupar notificações por data
  const groupedNotifications = notifications.reduce((groups, notification) => {
    const date = new Date(notification.created_at);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    let groupKey;
    if (date.toDateString() === today.toDateString()) {
      groupKey = 'Hoje';
    } else if (date.toDateString() === yesterday.toDateString()) {
      groupKey = 'Ontem';
    } else {
      groupKey = date.toLocaleDateString('pt-BR');
    }

    if (!groups[groupKey]) {
      groups[groupKey] = [];
    }
    groups[groupKey].push(notification);
    return groups;
  }, {} as Record<string, Notification[]>);

  if (!user) {
    return null;
  }

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative hover:bg-gray-100 transition-colors">
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs animate-pulse"
            >
              {unreadCount > 99 ? '99+' : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 p-0" align="end">
        <div className="bg-white rounded-lg shadow-lg border">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b">
            <h4 className="font-semibold text-community-primary">Notificações</h4>
            <div className="flex items-center space-x-2">
              {unreadCount > 0 && (
                <Badge variant="secondary" className="text-xs">
                  {unreadCount} nova{unreadCount !== 1 ? 's' : ''}
                </Badge>
              )}
              {unreadCount > 0 && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => markAllAsReadMutation.mutate()}
                  disabled={markAllAsReadMutation.isPending}
                  className="text-xs hover:bg-gray-100"
                >
                  <Check className="w-3 h-3 mr-1" />
                  Marcar todas como lidas
                </Button>
              )}
            </div>
          </div>
          
          {/* Content */}
          <div className="max-h-96 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="text-center py-8 px-4">
                <Bell className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">
                  Nenhuma notificação
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Você será notificado sobre atualizações importantes aqui
                </p>
              </div>
            ) : (
              <div className="divide-y">
                {Object.entries(groupedNotifications).map(([dateGroup, groupNotifications]) => (
                  <div key={dateGroup}>
                    <div className="px-4 py-2 bg-gray-50 border-b">
                      <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">
                        {dateGroup}
                      </p>
                    </div>
                    {groupNotifications.map((notification) => (
                      <Card 
                        key={notification.id} 
                        className={getNotificationStyle(notification.type, notification.read)}
                        onClick={() => {
                          if (!notification.read) {
                            markAsReadMutation.mutate(notification.id);
                          }
                        }}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start space-x-3">
                            <div className="flex-shrink-0 mt-1">
                              {getNotificationIcon(notification.type)}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between">
                                <div className="flex-1">
                                  <p className="font-medium text-sm text-community-primary mb-1">
                                    {notification.title}
                                  </p>
                                  <p className="text-sm text-community-secondary leading-relaxed">
                                    {notification.message}
                                  </p>
                                  <p className="text-xs text-gray-500 mt-2">
                                    {formatDate(notification.created_at)}
                                  </p>
                                </div>
                                <div className="flex items-center space-x-1 ml-2">
                                  {!notification.read && (
                                    <div className="w-2 h-2 bg-blue-500 rounded-full" />
                                  )}
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      removeNotificationMutation.mutate(notification.id);
                                    }}
                                    className="h-6 w-6 p-0 text-gray-400 hover:text-red-500 hover:bg-red-50"
                                  >
                                    <X className="w-3 h-3" />
                                  </Button>
                                </div>
                              </div>
                              
                              {/* Dados adicionais para notificações específicas */}
                              {notification.data && (
                                <div className="mt-2 p-2 bg-gray-50 rounded text-xs text-gray-600">
                                  {notification.data.auto_promoted && (
                                    <p>✨ Você é o primeiro usuário da comunidade!</p>
                                  )}
                                  {notification.data.approved_by && (
                                    <p>👤 Aprovado por administrador</p>
                                  )}
                                  {notification.data.reason && (
                                    <p>💬 Motivo: {notification.data.reason}</p>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* Footer */}
          {notifications.length > 0 && (
            <div className="p-3 border-t bg-gray-50 text-center">
              <p className="text-xs text-gray-500">
                Mostrando {notifications.length} notificação{notifications.length !== 1 ? 'ões' : ''} mais recente{notifications.length !== 1 ? 's' : ''}
              </p>
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
