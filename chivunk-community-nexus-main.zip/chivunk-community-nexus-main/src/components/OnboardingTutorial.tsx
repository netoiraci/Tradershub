
import { useState } from 'react';
import { ChevronLeft, ChevronRight, Play, Users, TrendingUp, MessageSquare, Target } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface OnboardingTutorialProps {
  onComplete: () => void;
}

const tutorialSteps = [
  {
    icon: Users,
    title: "Bem-vindo à Trading Community",
    content: "Esta é uma plataforma onde traders se conectam, compartilham conhecimento e crescem juntos. Vamos te mostrar como aproveitar ao máximo!",
    tips: ["Navegue pelas diferentes seções na barra lateral", "Cada espaço tem um propósito específico", "Participe das discussões para ganhar experiência"]
  },
  {
    icon: MessageSquare,
    title: "Criando seu Primeiro Post",
    content: "Compartilhe suas análises, estratégias e perguntas. A comunidade está aqui para ajudar e aprender junto.",
    tips: ["Use títulos claros e descritivos", "Seja específico sobre ativos e timeframes", "Adicione contexto às suas análises"]
  },
  {
    icon: TrendingUp,
    title: "Navegando pelos Espaços",
    content: "Cada seção tem um foco específico. Escolha o local certo para seu conteúdo para maximizar o engajamento.",
    tips: ["Análise Técnica: Para gráficos e indicadores", "Estratégias: Para métodos e sistemas", "Apresentações: Para se conhecer"]
  },
  {
    icon: Target,
    title: "Sistema de Gamificação",
    content: "Ganhe XP e níveis participando ativamente. Quanto mais você contribui, mais reconhecimento você ganha na comunidade.",
    tips: ["Posts e comentários geram XP", "Curtidas aumentam seu reconhecimento", "Participe dos desafios quando disponíveis"]
  }
];

export function OnboardingTutorial({ onComplete }: OnboardingTutorialProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const currentTutorial = tutorialSteps[currentStep];

  const nextStep = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <Card className="community-card mb-8">
      <CardContent className="p-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-[rgb(var(--community-accent))] rounded-xl flex items-center justify-center">
              <Play className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-community-primary">Guia de Início</h3>
              <p className="text-sm text-community-secondary">Passo {currentStep + 1} de {tutorialSteps.length}</p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-4 mb-6">
          <div className="w-16 h-16 bg-[rgb(var(--community-card))] rounded-2xl flex items-center justify-center">
            <currentTutorial.icon className="w-8 h-8 text-[rgb(var(--community-accent))]" />
          </div>
          <div className="flex-1">
            <h4 className="text-lg font-semibold text-community-primary mb-2">{currentTutorial.title}</h4>
            <p className="text-community-secondary">{currentTutorial.content}</p>
          </div>
        </div>

        <div className="bg-[rgb(var(--community-card))] rounded-xl p-4 mb-6">
          <h5 className="font-medium text-community-primary mb-3">💡 Dicas importantes:</h5>
          <ul className="space-y-2">
            {currentTutorial.tips.map((tip, index) => (
              <li key={index} className="text-sm text-community-secondary flex items-start">
                <span className="text-[rgb(var(--community-accent))] mr-2">•</span>
                {tip}
              </li>
            ))}
          </ul>
        </div>

        <div className="flex items-center justify-between">
          <Button
            onClick={prevStep}
            disabled={currentStep === 0}
            variant="ghost"
            className="btn-community-ghost"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Anterior
          </Button>

          <div className="flex space-x-2">
            {tutorialSteps.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full ${
                  index === currentStep 
                    ? 'bg-[rgb(var(--community-accent))]' 
                    : 'bg-[rgb(var(--community-border))]'
                }`}
              />
            ))}
          </div>

          <Button onClick={nextStep} className="btn-community-primary">
            {currentStep === tutorialSteps.length - 1 ? 'Começar!' : 'Próximo'}
            {currentStep !== tutorialSteps.length - 1 && <ChevronRight className="w-4 h-4 ml-2" />}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
