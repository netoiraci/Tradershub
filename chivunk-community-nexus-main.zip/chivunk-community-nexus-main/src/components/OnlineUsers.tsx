
import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Users, Circle, Crown } from 'lucide-react';
import { useOnlineUsers } from '@/hooks/useUserPresence';
import { useAuth } from '@/contexts/AuthContext';

interface OnlineUsersProps {
  roomId?: string;
  currentUserId?: string;
}

export function OnlineUsers({ roomId, currentUserId }: OnlineUsersProps) {
  const { user } = useAuth();
  const { data: onlineUsers = [], isLoading } = useOnlineUsers(roomId);

  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'online':
        return 'text-green-500';
      case 'away':
        return 'text-yellow-500';
      case 'busy':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };

  const getStatusText = (status?: string) => {
    switch (status) {
      case 'online':
        return 'Online';
      case 'away':
        return 'Ausente';
      case 'busy':
        return 'Ocupado';
      default:
        return 'Offline';
    }
  };

  if (isLoading) {
    return (
      <div className="h-full community-card">
        <div className="flex items-center space-x-2 p-3 border-b border-community-border">
          <Users className="w-4 h-4 text-community-muted" />
          <span className="text-sm font-semibold text-community-primary">
            Carregando...
          </span>
        </div>
        <div className="p-3 space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-12 bg-community-card-hover rounded animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  // Filtrar usuários únicos (caso haja duplicatas)
  const uniqueUsers = onlineUsers.reduce((acc, current) => {
    const existing = acc.find(user => user.user_id === current.user_id);
    if (!existing) {
      acc.push(current);
    }
    return acc;
  }, [] as typeof onlineUsers);

  return (
    <div className="h-full community-card overflow-hidden">
      <div className="flex items-center space-x-2 p-3 border-b border-community-border bg-community-card-hover">
        <Users className="w-4 h-4 text-community-muted" />
        <span className="text-sm font-semibold text-community-primary">
          Online — {uniqueUsers.length}
        </span>
      </div>

      <div className="p-3 space-y-2 overflow-y-auto flex-1 max-h-[calc(100%-60px)]">
        {uniqueUsers.map((presence) => {
          const isCurrentUser = presence.user_id === user?.id;
          const userName = presence.profiles?.name || 'Usuário';
          
          return (
            <div
              key={presence.id}
              className={`flex items-center space-x-3 p-2 rounded-lg hover:bg-community-card-hover transition-colors ${
                isCurrentUser ? 'bg-community-card border border-community-border' : ''
              }`}
            >
              <div className="relative">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={presence.profiles?.avatar_url || ''} />
                  <AvatarFallback className="bg-community-accent text-white text-xs">
                    {userName.split(' ').map(n => n[0]).join('').slice(0, 2)}
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-1 -right-1">
                  <Circle 
                    className={`w-3 h-3 ${getStatusColor(presence.status)} border-2 border-community-card rounded-full`}
                    fill="currentColor"
                  />
                </div>
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-1">
                  <span className="text-sm font-medium text-community-primary truncate">
                    {userName}
                  </span>
                  {isCurrentUser && (
                    <>
                      <Crown className="w-3 h-3 text-yellow-500" />
                      <span className="text-xs text-community-muted">(você)</span>
                    </>
                  )}
                </div>
                <div className={`text-xs ${getStatusColor(presence.status)} capitalize`}>
                  {getStatusText(presence.status)}
                </div>
              </div>
            </div>
          );
        })}
        
        {uniqueUsers.length === 0 && (
          <div className="text-center text-community-muted py-8">
            <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">Nenhum usuário online</p>
          </div>
        )}
      </div>
    </div>
  );
}
