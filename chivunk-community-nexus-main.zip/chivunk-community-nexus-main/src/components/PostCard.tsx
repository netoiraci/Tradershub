
import { Heart, MessageCircle, Share } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { LinkifiedText } from '@/components/LinkifiedText';
import { PostModal } from '@/components/PostModal';
import { useAuth } from '@/contexts/AuthContext';
import { usePostLike, useToggleLike } from '@/hooks/useLikes';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useState } from 'react';

interface PostCardProps {
  id: string;
  title: string;
  content: string;
  category?: string | null;
  section: string;
  likes_count: number;
  comments_count: number;
  shares_count: number;
  created_at: string;
  user_id: string;
  profiles?: {
    name: string | null;
  };
}

export function PostCard({
  id,
  title,
  content,
  category,
  section,
  likes_count,
  comments_count,
  shares_count,
  created_at,
  user_id,
  profiles
}: PostCardProps) {
  const { user } = useAuth();
  const { data: isLiked = false } = usePostLike(id);
  const toggleLike = useToggleLike();
  const [showModal, setShowModal] = useState(false);

  const handleLike = async () => {
    if (!user) {
      return;
    }

    toggleLike.mutate({
      postId: id,
      isLiked
    });
  };

  const handleOpenComments = () => {
    setShowModal(true);
  };

  const authorName = profiles?.name || 'Usuário';
  const timeAgo = formatDistanceToNow(new Date(created_at), { 
    addSuffix: true,
    locale: ptBR 
  });

  const post = {
    id,
    title,
    content,
    category,
    section,
    likes_count,
    comments_count,
    shares_count,
    created_at,
    user_id,
    profiles
  };

  return (
    <>
      <div className="bg-[#1E1E1E] border border-[#2C2C2C] rounded-2xl p-8 mb-6 transition-all duration-300 hover:bg-[#2C2C2C] hover:border-[#4B4B4B] hover:shadow-lg hover:shadow-black/20 cursor-pointer group">
        {/* Header */}
        <div className="flex items-start space-x-4 mb-4">
          <Avatar className="w-12 h-12 flex-shrink-0 ring-2 ring-transparent group-hover:ring-[#4B4B4B] transition-all duration-200">
            <AvatarImage src="" />
            <AvatarFallback className="bg-[#4B4B4B] text-white text-sm font-medium">
              {authorName.split(' ').map(n => n[0]).join('').slice(0, 2)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0 space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-[#FFFFFF] text-sm truncate pr-2 group-hover:text-white transition-colors duration-200">{authorName}</h4>
              <span className="text-xs text-[#A3A3A3] flex-shrink-0">{timeAgo}</span>
            </div>
            {category && (
              <span className="inline-block text-xs bg-[#4B4B4B]/30 text-[#4B4B4B] px-3 py-1 rounded-full border border-[#4B4B4B]/20 group-hover:bg-[#4B4B4B]/40 transition-all duration-200">
                {category}
              </span>
            )}
          </div>
        </div>

        {/* Content */}
        <div className="mb-4">
          <h3 className="font-semibold text-[#FFFFFF] text-lg mb-3 leading-tight group-hover:text-white transition-colors duration-200">
            <LinkifiedText text={title} section={section} />
          </h3>
          <div className="text-[#A3A3A3] text-sm leading-relaxed group-hover:text-[#FFFFFF]/80 transition-colors duration-200">
            <LinkifiedText text={content} section={section} />
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-6 pt-3 border-t border-[#2C2C2C] group-hover:border-[#4B4B4B] transition-colors duration-200">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleOpenComments}
            className="flex items-center space-x-2 p-2 h-auto text-[#A3A3A3] hover:text-[#FFFFFF] hover:bg-[#4B4B4B]/20 rounded-lg transition-all duration-200"
          >
            <MessageCircle className="w-4 h-4" />
            <span className="text-sm font-medium">{comments_count}</span>
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLike}
            disabled={toggleLike.isPending || !user}
            className={`flex items-center space-x-2 p-2 h-auto rounded-lg transition-all duration-200 ${
              isLiked 
                ? 'text-red-500 hover:text-red-400 hover:bg-red-500/10' 
                : 'text-[#A3A3A3] hover:text-[#FFFFFF] hover:bg-[#4B4B4B]/20'
            }`}
          >
            <Heart className={`w-4 h-4 transition-all duration-200 ${isLiked ? 'fill-current scale-110' : ''}`} />
            <span className="text-sm font-medium">{likes_count}</span>
          </Button>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {}}
            className="flex items-center space-x-2 p-2 h-auto text-[#A3A3A3] hover:text-[#FFFFFF] hover:bg-[#4B4B4B]/20 rounded-lg transition-all duration-200"
          >
            <Share className="w-4 h-4" />
            <span className="text-sm font-medium">{shares_count}</span>
          </Button>
        </div>
      </div>

      <PostModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        post={post}
      />
    </>
  );
}
