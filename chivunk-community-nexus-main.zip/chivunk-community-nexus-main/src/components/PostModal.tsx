
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Heart, MessageCircle, Share, X } from 'lucide-react';
import { LinkifiedText } from '@/components/LinkifiedText';
import { CommentThread } from '@/components/CommentThread';
import { useAuth } from '@/contexts/AuthContext';
import { usePostLike, useToggleLike } from '@/hooks/useLikes';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface PostModalProps {
  isOpen: boolean;
  onClose: () => void;
  post: {
    id: string;
    title: string;
    content: string;
    category?: string | null;
    section: string;
    likes_count: number;
    comments_count: number;
    shares_count: number;
    created_at: string;
    user_id: string;
    profiles?: {
      name: string | null;
    };
  };
}

export function PostModal({ isOpen, onClose, post }: PostModalProps) {
  const { user } = useAuth();
  const { data: isLiked = false } = usePostLike(post.id);
  const toggleLike = useToggleLike();

  const handleLike = async () => {
    if (!user) return;

    toggleLike.mutate({
      postId: post.id,
      isLiked
    });
  };

  const authorName = post.profiles?.name || 'Usuário';
  const timeAgo = formatDistanceToNow(new Date(post.created_at), { 
    addSuffix: true,
    locale: ptBR 
  });

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden bg-[#1E1E1E] border border-[#2C2C2C] text-white">
        <DialogHeader className="border-b border-[#2C2C2C] pb-4">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-semibold text-white">
              Comentários
            </DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-[#A3A3A3] hover:text-white"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="flex flex-col h-full overflow-hidden">
          {/* Post content */}
          <div className="flex-shrink-0 p-6 border-b border-[#2C2C2C]">
            <div className="flex items-start space-x-4 mb-4">
              <Avatar className="w-12 h-12 flex-shrink-0">
                <AvatarImage src="" />
                <AvatarFallback className="bg-[#4B4B4B] text-white text-sm font-medium">
                  {authorName.split(' ').map(n => n[0]).join('').slice(0, 2)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-white text-sm">{authorName}</h4>
                  <span className="text-xs text-[#A3A3A3]">{timeAgo}</span>
                </div>
                {post.category && (
                  <span className="inline-block text-xs bg-[#4B4B4B]/30 text-[#4B4B4B] px-3 py-1 rounded-full border border-[#4B4B4B]/20">
                    {post.category}
                  </span>
                )}
              </div>
            </div>

            <div className="mb-4">
              <h3 className="font-semibold text-white text-lg mb-3 leading-tight">
                <LinkifiedText text={post.title} section={post.section} />
              </h3>
              <div className="text-[#A3A3A3] text-sm leading-relaxed">
                <LinkifiedText text={post.content} section={post.section} />
              </div>
            </div>

            {/* Post actions */}
            <div className="flex items-center space-x-6 pt-3 border-t border-[#2C2C2C]">
              <div className="flex items-center space-x-2 text-[#A3A3A3]">
                <MessageCircle className="w-4 h-4" />
                <span className="text-sm font-medium">{post.comments_count}</span>
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLike}
                disabled={toggleLike.isPending || !user}
                className={`flex items-center space-x-2 p-2 h-auto rounded-lg transition-all duration-200 ${
                  isLiked 
                    ? 'text-red-500 hover:text-red-400 hover:bg-red-500/10' 
                    : 'text-[#A3A3A3] hover:text-white hover:bg-[#4B4B4B]/20'
                }`}
              >
                <Heart className={`w-4 h-4 transition-all duration-200 ${isLiked ? 'fill-current scale-110' : ''}`} />
                <span className="text-sm font-medium">{post.likes_count}</span>
              </Button>
              
              <div className="flex items-center space-x-2 text-[#A3A3A3]">
                <Share className="w-4 h-4" />
                <span className="text-sm font-medium">{post.shares_count}</span>
              </div>
            </div>
          </div>

          {/* Comments section */}
          <div className="flex-1 overflow-y-auto p-6">
            <CommentThread postId={post.id} />
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
