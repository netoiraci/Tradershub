
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { X, User, Trophy, Target } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PresentationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Presentation {
  id: string;
  name: string;
  experience: string;
  objective: string;
  date: string;
}

// Mock data - será substituído pelo Supabase
const mockPresentations: Presentation[] = [
  {
    id: '1',
    name: 'João Silva',
    experience: '2 anos de trading',
    objective: 'Aprender análise técnica avançada',
    date: '2024-01-15'
  },
  {
    id: '2',
    name: 'Maria Santos',
    experience: 'Iniciante no mercado',
    objective: 'Entender o básico de forex',
    date: '2024-01-14'
  }
];

export function PresentationModal({ isOpen, onClose }: PresentationModalProps) {
  const [name, setName] = useState('');
  const [experience, setExperience] = useState('');
  const [objective, setObjective] = useState('');
  const [presentations, setPresentations] = useState<Presentation[]>(mockPresentations);
  const { toast } = useToast();

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name || !experience || !objective) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos",
        variant: "destructive"
      });
      return;
    }

    const newPresentation: Presentation = {
      id: Date.now().toString(),
      name,
      experience,
      objective,
      date: new Date().toISOString().split('T')[0]
    };

    setPresentations(prev => [newPresentation, ...prev]);
    setName('');
    setExperience('');
    setObjective('');
    
    toast({
      title: "Apresentação enviada!",
      description: "Sua apresentação foi salva com sucesso",
    });
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-primary flex items-center">
            <User className="w-6 h-6 mr-3 text-accent" />
            Apresente-se à Comunidade
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-10 w-10 p-0 text-muted hover:text-primary rounded-lg"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 mb-8">
          <div>
            <label className="block text-sm font-semibold text-primary mb-2">
              Nome
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="input-field"
              placeholder="Seu nome completo"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-primary mb-2 flex items-center">
              <Trophy className="w-4 h-4 mr-2" />
              Experiência de Trading
            </label>
            <textarea
              value={experience}
              onChange={(e) => setExperience(e.target.value)}
              className="input-field h-24 resize-none"
              placeholder="Ex: 3 anos operando forex, especialista em análise técnica..."
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-primary mb-2 flex items-center">
              <Target className="w-4 h-4 mr-2" />
              Objetivo na Comunidade
            </label>
            <textarea
              value={objective}
              onChange={(e) => setObjective(e.target.value)}
              className="input-field h-24 resize-none"
              placeholder="Ex: Aprender novas estratégias, compartilhar conhecimento..."
            />
          </div>

          <Button
            type="submit"
            className="w-full trading-button"
          >
            Enviar Apresentação
          </Button>
        </form>

        <div className="border-t border-[rgb(var(--trading-border))] pt-6">
          <h3 className="text-lg font-semibold text-primary mb-4">
            Apresentações Recentes ({presentations.length})
          </h3>
          
          <div className="max-h-64 overflow-y-auto space-y-4">
            {presentations.map((presentation) => (
              <div
                key={presentation.id}
                className="trading-card p-4 hover:bg-[rgb(var(--trading-surface-hover))] transition-colors"
              >
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold text-primary">{presentation.name}</h4>
                  <span className="text-xs text-muted bg-[rgb(var(--trading-surface-hover))] px-2 py-1 rounded-md">
                    {new Date(presentation.date).toLocaleDateString('pt-BR')}
                  </span>
                </div>
                <p className="text-sm text-secondary mb-2">
                  <strong>Experiência:</strong> {presentation.experience}
                </p>
                <p className="text-sm text-secondary">
                  <strong>Objetivo:</strong> {presentation.objective}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
