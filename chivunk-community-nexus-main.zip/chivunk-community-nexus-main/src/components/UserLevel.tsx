
import { Crown, Star, Zap } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface UserLevelProps {
  level: number;
  xp: number;
  xpToNext: number;
  username?: string;
  compact?: boolean;
}

const getLevelInfo = (level: number) => {
  const levels = [
    { name: 'Novato', color: 'text-gray-400', icon: Star },
    { name: 'Trader Júnior', color: 'text-blue-400', icon: Star },
    { name: 'Trader', color: 'text-green-400', icon: Zap },
    { name: 'Trader Senior', color: 'text-purple-400', icon: Zap },
    { name: 'Expert', color: 'text-orange-400', icon: Crown },
    { name: 'Mestre', color: 'text-yellow-400', icon: Crown },
  ];
  
  const levelIndex = Math.min(Math.floor(level / 5), levels.length - 1);
  return levels[levelIndex];
};

export function UserLevel({ level, xp, xpToNext, username, compact = false }: UserLevelProps) {
  const levelInfo = getLevelInfo(level);
  const IconComponent = levelInfo.icon;
  const progress = (xp / (xp + xpToNext)) * 100;

  if (compact) {
    return (
      <div className="flex items-center space-x-2">
        <div className={`w-5 h-5 rounded flex items-center justify-center bg-[rgb(var(--community-card))]`}>
          <IconComponent className={`w-3 h-3 ${levelInfo.color}`} />
        </div>
        <Badge variant="outline" className="text-xs px-2 py-0">
          Nv. {level}
        </Badge>
      </div>
    );
  }

  return (
    <div className="bg-[rgb(var(--community-card))] rounded-xl p-4 border border-[rgb(var(--community-border))]">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className={`w-10 h-10 rounded-xl bg-[rgb(var(--community-bg))] flex items-center justify-center`}>
            <IconComponent className={`w-5 h-5 ${levelInfo.color}`} />
          </div>
          <div>
            <h4 className="font-medium text-community-primary">{levelInfo.name}</h4>
            <p className="text-sm text-community-secondary">Nível {level}</p>
          </div>
        </div>
        {username && (
          <Badge variant="outline" className="text-xs">
            {username}
          </Badge>
        )}
      </div>
      
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-community-secondary">{xp} XP</span>
          <span className="text-community-secondary">{xpToNext} para próximo nível</span>
        </div>
        <div className="w-full bg-[rgb(var(--community-bg))] rounded-full h-2">
          <div 
            className="bg-[rgb(var(--community-accent))] h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
    </div>
  );
}
