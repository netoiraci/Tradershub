import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Camera, User, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';

export function UserSettings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [name, setName] = useState(user?.user_metadata?.name || '');
  const [uploadingImage, setUploadingImage] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState('');

  const updateProfile = useMutation({
    mutationFn: async ({ name, avatarUrl }: { name: string; avatarUrl?: string }) => {
      if (!user) throw new Error('User not authenticated');

      const updates: any = { name };
      if (avatarUrl) updates.avatar_url = avatarUrl;

      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: 'Perfil atualizado',
        description: 'Suas alterações foram salvas com sucesso.',
      });
      queryClient.invalidateQueries({ queryKey: ['profile'] });
    },
    onError: (error) => {
      toast({
        title: 'Erro ao atualizar perfil',
        description: 'Ocorreu um erro ao salvar suas alterações.',
        variant: 'destructive',
      });
      console.error('Error updating profile:', error);
    }
  });

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;

    setUploadingImage(true);

    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;
      const filePath = `avatars/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      setAvatarUrl(data.publicUrl);
      
      toast({
        title: 'Imagem carregada',
        description: 'Sua foto de perfil foi carregada. Clique em salvar para confirmar.',
      });
    } catch (error) {
      console.error('Error uploading image:', error);
      toast({
        title: 'Erro no upload',
        description: 'Não foi possível carregar a imagem.',
        variant: 'destructive',
      });
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSave = () => {
    updateProfile.mutate({ name, avatarUrl });
  };

  return (
    <div className="community-card p-6 space-y-6">
      <div className="flex items-center space-x-3 mb-6">
        <User className="w-6 h-6 text-community-accent" />
        <h2 className="text-xl font-semibold text-community-primary">
          Configurações do Perfil
        </h2>
      </div>

      {/* Avatar Upload */}
      <div className="flex flex-col items-center space-y-4">
        <div className="relative">
          <Avatar className="w-24 h-24">
            <AvatarImage src={avatarUrl || ''} />
            <AvatarFallback className="bg-community-accent text-white text-xl">
              {name?.[0]?.toUpperCase() || user?.email?.[0]?.toUpperCase() || 'U'}
            </AvatarFallback>
          </Avatar>
          
          <label 
            htmlFor="avatar-upload" 
            className="absolute bottom-0 right-0 bg-community-accent hover:bg-community-primary text-white rounded-full p-2 cursor-pointer transition-colors shadow-lg"
          >
            <Camera className="w-4 h-4" />
          </label>
          
          <input
            id="avatar-upload"
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
            disabled={uploadingImage}
          />
        </div>
        
        {uploadingImage && (
          <p className="text-sm text-community-secondary">Carregando imagem...</p>
        )}
      </div>

      {/* Name Input */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-community-primary">
          Nome
        </label>
        <Input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Seu nome"
          className="input-community"
        />
      </div>

      {/* Email (read-only) */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-community-primary">
          Email
        </label>
        <Input
          value={user?.email || ''}
          disabled
          className="input-community opacity-60"
        />
      </div>

      {/* Save Button */}
      <Button
        onClick={handleSave}
        disabled={updateProfile.isPending}
        className="w-full btn-community-primary"
      >
        <Save className="w-4 h-4 mr-2" />
        {updateProfile.isPending ? 'Salvando...' : 'Salvar Alterações'}
      </Button>
    </div>
  );
}