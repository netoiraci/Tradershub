
import React, { useState } from 'react';
import { Trophy, Calendar, Users, TrendingUp, Target, Plus } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';

export function WeeklyChallenges() {
  const { user } = useAuth();

  if (!user) return null;

  return (
    <Card className="community-card">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-[rgb(var(--community-accent))] rounded-lg flex items-center justify-center">
              <Trophy className="w-4 h-4 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-community-primary">Desafios da Comunidade</h3>
          </div>
        </div>

        {/* Empty state - nenhum desafio ativo */}
        <div className="text-center py-8">
          <div className="w-16 h-16 bg-[rgb(var(--community-card))] rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Trophy className="w-8 h-8 text-[rgb(var(--community-accent))]" />
          </div>
          
          <h4 className="text-lg font-semibold text-community-primary mb-2">
            Primeiro Desafio em Breve!
          </h4>
          
          <p className="text-community-secondary mb-6 max-w-sm mx-auto">
            Os desafios semanais serão lançados em breve. Fique atento para participar e ganhar reconhecimento na comunidade.
          </p>

          <div className="bg-[rgb(var(--community-card))] rounded-xl p-4 mb-6">
            <h5 className="font-medium text-community-primary mb-3">💡 Como funcionarão:</h5>
            <ul className="space-y-2 text-sm text-community-secondary text-left">
              <li className="flex items-start">
                <span className="text-[rgb(var(--community-accent))] mr-2">•</span>
                Desafios semanais sobre análise técnica
              </li>
              <li className="flex items-start">
                <span className="text-[rgb(var(--community-accent))] mr-2">•</span>
                Competições de estratégias de trading
              </li>
              <li className="flex items-start">
                <span className="text-[rgb(var(--community-accent))] mr-2">•</span>
                Debates sobre mercado e economia
              </li>
              <li className="flex items-start">
                <span className="text-[rgb(var(--community-accent))] mr-2">•</span>
                Recompensas e reconhecimento
              </li>
            </ul>
          </div>

          <div className="flex justify-center">
            <Button className="btn-community-primary" disabled>
              <Plus className="w-4 h-4 mr-2" />
              Em Desenvolvimento
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
