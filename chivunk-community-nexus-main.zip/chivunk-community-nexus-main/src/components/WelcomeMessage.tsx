
import { useState } from 'react';
import { X, TrendingUp, Users, MessageSquare } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface WelcomeMessageProps {
  onClose: () => void;
}

export function WelcomeMessage({ onClose }: WelcomeMessageProps) {
  return (
    <Card className="community-card border-2 border-[rgb(var(--community-accent))] mb-8">
      <CardContent className="p-8">
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-[rgb(var(--community-accent))] rounded-xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-community-primary">Bem-vindo(a) à Trading Community!</h2>
              <p className="text-community-secondary">Sua jornada de trading começa aqui</p>
            </div>
          </div>
          <Button
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="text-community-secondary hover:text-community-primary"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-[rgb(var(--community-card))] rounded-2xl flex items-center justify-center mx-auto mb-3">
              <MessageSquare className="w-8 h-8 text-[rgb(var(--community-accent))]" />
            </div>
            <h3 className="font-semibold text-community-primary mb-2">Compartilhe Estratégias</h3>
            <p className="text-sm text-community-secondary">Discuta suas análises técnicas e estratégias de trading</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-[rgb(var(--community-card))] rounded-2xl flex items-center justify-center mx-auto mb-3">
              <TrendingUp className="w-8 h-8 text-[rgb(var(--community-accent))]" />
            </div>
            <h3 className="font-semibold text-community-primary mb-2">Analise Mercados</h3>
            <p className="text-sm text-community-secondary">Acompanhe análises de mercado em tempo real</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-[rgb(var(--community-card))] rounded-2xl flex items-center justify-center mx-auto mb-3">
              <Users className="w-8 h-8 text-[rgb(var(--community-accent))]" />
            </div>
            <h3 className="font-semibold text-community-primary mb-2">Conecte-se</h3>
            <p className="text-sm text-community-secondary">Faça networking com outros traders experientes</p>
          </div>
        </div>

        <div className="bg-[rgb(var(--community-card))] rounded-xl p-4 mb-6">
          <h4 className="font-semibold text-community-primary mb-2">📍 Primeiros Passos:</h4>
          <ul className="space-y-2 text-sm text-community-secondary">
            <li>1. Se apresente na seção "Apresentações"</li>
            <li>2. Explore as discussões técnicas ativas</li>
            <li>3. Compartilhe sua primeira análise ou estratégia</li>
            <li>4. Participe dos desafios semanais</li>
          </ul>
        </div>

        <div className="flex justify-center">
          <Button onClick={onClose} className="btn-community-primary">
            Começar a Explorar
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
