import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, Users, TrendingUp, Shield, Sparkles } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';

interface WelcomeModalProps {
  open: boolean;
  onClose: () => void;
}

export function WelcomeModal({ open, onClose }: WelcomeModalProps) {
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    if (user) {
      checkIsAdmin();
    }
  }, [user]);

  const checkIsAdmin = async () => {
    if (!user) return;
    
    const { data } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .eq('role', 'admin');
    
    setIsAdmin(data && data.length > 0);
  };

  const features = [
    {
      icon: <MessageCircle className="w-5 h-5" />,
      title: 'Chat em Tempo Real',
      description: 'Converse com outros traders em salas temáticas'
    },
    {
      icon: <TrendingUp className="w-5 h-5" />,
      title: 'Análises e Estratégias',
      description: 'Compartilhe e descubra novas estratégias de trading'
    },
    {
      icon: <Users className="w-5 h-5" />,
      title: 'Comunidade Ativa',
      description: 'Conecte-se com traders de todos os níveis'
    }
  ];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-community-card border-community-border">
        <DialogHeader className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-community-accent to-community-primary rounded-full flex items-center justify-center">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <DialogTitle className="text-2xl text-community-primary">
            Bem-vindo à Trading Community!
          </DialogTitle>
          {isAdmin && (
            <Badge className="mx-auto bg-blue-500/20 text-blue-400 border-blue-500/30">
              <Shield className="w-3 h-3 mr-1" />
              Administrador
            </Badge>
          )}
        </DialogHeader>

        <div className="space-y-4 py-4">
          <p className="text-center text-community-secondary">
            Sua conta foi aprovada! Agora você tem acesso a todas as funcionalidades da nossa comunidade de trading.
          </p>

          <div className="space-y-3">
            {features.map((feature, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 rounded-lg bg-community-card-hover">
                <div className="text-community-accent mt-0.5">
                  {feature.icon}
                </div>
                <div>
                  <h4 className="text-sm font-medium text-community-primary">
                    {feature.title}
                  </h4>
                  <p className="text-xs text-community-secondary">
                    {feature.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {isAdmin && (
            <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
              <p className="text-sm text-blue-400">
                🎉 Como primeiro usuário, você foi promovido a administrador! 
                Acesse o painel admin para gerenciar a comunidade.
              </p>
            </div>
          )}
        </div>

        <div className="flex flex-col gap-2 pt-4">
          <Button
            onClick={onClose}
            className="w-full bg-community-accent hover:bg-community-accent/90 text-white"
          >
            Começar a explorar
          </Button>
          <p className="text-xs text-center text-community-secondary">
            Você pode acessar o chat e começar a interagir imediatamente
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}