
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity } from 'lucide-react';
import { formatDate, getActionIcon, getActionLabel } from '@/utils/adminUtils';

interface AdminLog {
  id: string;
  action: string;
  details: any;
  created_at: string;
  admin_id: string;
  target_user_id: string | null;
}

interface AdminLogsTabProps {
  adminLogs: AdminLog[];
  loadingLogs: boolean;
}

export function AdminLogsTab({ adminLogs, loadingLogs }: AdminLogsTabProps) {
  return (
    <Card className="community-card border-[rgb(var(--community-border))]">
      <CardHeader>
        <CardTitle className="text-community-primary">Histórico de Ações Administrativas</CardTitle>
      </CardHeader>
      <CardContent>
        {loadingLogs ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[rgb(var(--community-accent))]"></div>
          </div>
        ) : adminLogs.length === 0 ? (
          <div className="text-center py-8">
            <Activity className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-community-secondary">
              Nenhuma ação administrativa registrada ainda.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {adminLogs.map((log) => {
              const { Icon, className } = getActionIcon(log.action);
              
              return (
                <div
                  key={log.id}
                  className="flex items-center justify-between p-3 border border-[rgb(var(--community-border))] rounded-lg bg-[rgb(var(--community-card))] hover:bg-[rgb(var(--community-card-hover))] transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <Icon className={className} />
                    <div>
                      <p className="font-medium text-community-primary">
                        {getActionLabel(log.action)}
                      </p>
                      <p className="text-sm text-community-secondary">
                        {formatDate(log.created_at)}
                      </p>
                      {log.details && typeof log.details === 'object' && (
                        <p className="text-xs text-community-secondary">
                          {log.details.reason && `Motivo: ${log.details.reason}`}
                          {log.details.email && `Email: ${log.details.email}`}
                          {log.details.name && `Nome: ${log.details.name}`}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <Badge variant="outline" className="text-community-secondary border-[rgb(var(--community-border))]">
                    ID: {log.target_user_id?.slice(0, 8)}...
                  </Badge>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
