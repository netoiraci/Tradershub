
import { Card, CardContent } from '@/components/ui/card';
import { Clock, Users, XCircle, Shield, Activity } from 'lucide-react';

interface AdminStatsProps {
  stats?: {
    pending: number;
    approved: number;
    rejected: number;
    admins: number;
    total: number;
  };
}

export function AdminStats({ stats }: AdminStatsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
      <Card className="community-card border-[rgb(var(--community-border))]">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3">
            <Clock className="w-8 h-8 text-orange-400" />
            <div>
              <p className="text-2xl font-bold text-community-primary">
                {stats?.pending || 0}
              </p>
              <p className="text-sm text-community-secondary">Pendentes</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="community-card border-[rgb(var(--community-border))]">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3">
            <Users className="w-8 h-8 text-blue-400" />
            <div>
              <p className="text-2xl font-bold text-community-primary">
                {stats?.approved || 0}
              </p>
              <p className="text-sm text-community-secondary">Aprovados</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="community-card border-[rgb(var(--community-border))]">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3">
            <XCircle className="w-8 h-8 text-red-400" />
            <div>
              <p className="text-2xl font-bold text-community-primary">
                {stats?.rejected || 0}
              </p>
              <p className="text-sm text-community-secondary">Rejeitados</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="community-card border-[rgb(var(--community-border))]">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3">
            <Shield className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-2xl font-bold text-community-primary">
                {stats?.admins || 0}
              </p>
              <p className="text-sm text-community-secondary">Admins</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="community-card border-[rgb(var(--community-border))]">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3">
            <Activity className="w-8 h-8 text-purple-400" />
            <div>
              <p className="text-2xl font-bold text-community-primary">
                {stats?.total || 0}
              </p>
              <p className="text-sm text-community-secondary">Total</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
