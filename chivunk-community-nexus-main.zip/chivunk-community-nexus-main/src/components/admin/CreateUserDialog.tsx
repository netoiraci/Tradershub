
import { useForm } from 'react-hook-form';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import React from 'react';

interface CreateUserForm {
  name: string;
  email: string;
  password: string;
  bio?: string;
}

interface CreateUserDialogProps {
  open: boolean;
  onClose: () => void;
  onCreateUser: (data: CreateUserForm) => void;
  isLoading: boolean;
  children?: React.ReactNode; // <-- Accept children now
}

export function CreateUserDialog({
  open,
  onClose,
  onCreateUser,
  isLoading,
  children, // <-- receive children
}: CreateUserDialogProps) {
  const form = useForm<CreateUserForm>();

  const onSubmit = (data: CreateUserForm) => {
    onCreateUser(data);
    form.reset();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[rgb(var(--community-card))] border-[rgb(var(--community-border))]">
        <DialogHeader>
          <DialogTitle className="text-community-primary">Criar Novo Usuário</DialogTitle>
          <DialogDescription className="text-community-secondary">
            Crie um novo usuário manualmente. O usuário será automaticamente aprovado.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-community-primary">Nome</FormLabel>
                  <FormControl>
                    <Input placeholder="Nome do usuário" {...field} className="input-community" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-community-primary">Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="email@exemplo.com" {...field} className="input-community" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-community-primary">Senha</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="Senha" {...field} className="input-community" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="bio"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-community-primary">Bio (Opcional)</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Biografia do usuário" {...field} className="input-community" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            {/* Render children after the form fields for additional custom content */}
            {children}
            <DialogFooter>
              <Button type="submit" disabled={isLoading} className="bg-[rgb(var(--community-accent))] hover:bg-[rgb(var(--community-accent))]/90 text-white">
                {isLoading ? 'Criando...' : 'Criar Usuário'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
