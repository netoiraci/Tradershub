
import { useForm } from 'react-hook-form';
import { useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

interface User {
  id: string;
  name: string | null;
  status: string;
  created_at: string;
  bio: string | null;
  is_admin: boolean;
}

interface EditUserForm {
  name: string;
  bio?: string;
}

interface EditUserDialogProps {
  user: User | null;
  onClose: () => void;
  onEditUser: (data: EditUserForm) => void;
  isLoading: boolean;
}

export function EditUserDialog({
  user,
  onClose,
  onEditUser,
  isLoading
}: EditUserDialogProps) {
  const form = useForm<EditUserForm>();

  useEffect(() => {
    if (user) {
      form.setValue('name', user.name || '');
      form.setValue('bio', user.bio || '');
    }
  }, [user, form]);

  const onSubmit = (data: EditUserForm) => {
    onEditUser(data);
    form.reset();
  };

  return (
    <Dialog open={!!user} onOpenChange={onClose}>
      <DialogContent className="bg-[rgb(var(--community-card))] border-[rgb(var(--community-border))]">
        <DialogHeader>
          <DialogTitle className="text-community-primary">Editar Usuário</DialogTitle>
          <DialogDescription className="text-community-secondary">
            Edite as informações do usuário {user?.name}.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-community-primary">Nome</FormLabel>
                  <FormControl>
                    <Input placeholder="Nome do usuário" {...field} className="input-community" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="bio"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-community-primary">Bio</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Biografia do usuário" {...field} className="input-community" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="submit" disabled={isLoading} className="bg-[rgb(var(--community-accent))] hover:bg-[rgb(var(--community-accent))]/90 text-white">
                {isLoading ? 'Salvando...' : 'Salvar Alterações'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
