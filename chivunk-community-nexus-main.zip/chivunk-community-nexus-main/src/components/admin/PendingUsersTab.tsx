
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Check, X, Bell, CheckCircle } from 'lucide-react';
import { formatDate } from '@/utils/adminUtils';
import { RejectUserDialog } from './RejectUserDialog';

interface PendingUser {
  id: string;
  name: string | null;
  created_at: string;
  status: string;
}

interface PendingUsersTabProps {
  pendingUsers: PendingUser[];
  loadingUsers: boolean;
  onApproveUser: (userId: string) => void;
  onRejectUser: (userId: string, reason: string) => void;
  approvePending: boolean;
  rejectPending: boolean;
}

export function PendingUsersTab({
  pendingUsers,
  loadingUsers,
  onApproveUser,
  onRejectUser,
  approvePending,
  rejectPending
}: PendingUsersTabProps) {
  const [rejectingUser, setRejectingUser] = useState<PendingUser | null>(null);

  const handleRejectUser = (reason: string) => {
    if (rejectingUser) {
      onRejectUser(rejectingUser.id, reason);
      setRejectingUser(null);
    }
  };

  return (
    <>
      <Card className="community-card border-[rgb(var(--community-border))]">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-community-primary">
            <Bell className="w-5 h-5 text-orange-400" />
            <span>Usuários Aguardando Aprovação</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loadingUsers ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[rgb(var(--community-accent))]"></div>
            </div>
          ) : pendingUsers.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-3" />
              <p className="text-community-secondary">
                Não há usuários pendentes de aprovação.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {pendingUsers.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center justify-between p-4 border border-[rgb(var(--community-border))] rounded-lg bg-[rgb(var(--community-card))] hover:bg-[rgb(var(--community-card-hover))] transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <Avatar>
                      <AvatarFallback className="bg-[rgb(var(--community-accent))] text-white">
                        {user.name?.[0]?.toUpperCase() || '?'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h4 className="font-medium text-community-primary">
                        {user.name || 'Nome não informado'}
                      </h4>
                      <p className="text-sm text-community-secondary">
                        Registrado em: {formatDate(user.created_at)}
                      </p>
                      <Badge variant="secondary" className="mt-1 bg-orange-500/20 text-orange-400 border-orange-500/30">
                        Pendente
                      </Badge>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Button
                      size="sm"
                      onClick={() => onApproveUser(user.id)}
                      disabled={approvePending}
                      className="bg-green-600 hover:bg-green-700 text-white"
                    >
                      <Check className="w-4 h-4 mr-1" />
                      Aprovar
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => setRejectingUser(user)}
                      disabled={rejectPending}
                      className="bg-red-600 hover:bg-red-700 text-white"
                    >
                      <X className="w-4 h-4 mr-1" />
                      Rejeitar
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <RejectUserDialog
        user={rejectingUser}
        onReject={handleRejectUser}
        onClose={() => setRejectingUser(null)}
        isLoading={rejectPending}
      />
    </>
  );
}
