
import { useForm } from 'react-hook-form';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';

interface PendingUser {
  id: string;
  name: string | null;
  created_at: string;
  status: string;
}

interface RejectUserForm {
  reason: string;
}

interface RejectUserDialogProps {
  user: PendingUser | null;
  onReject: (reason: string) => void;
  onClose: () => void;
  isLoading: boolean;
}

export function RejectUserDialog({
  user,
  onReject,
  onClose,
  isLoading
}: RejectUserDialogProps) {
  const form = useForm<RejectUserForm>();

  const onSubmit = (data: RejectUserForm) => {
    onReject(data.reason);
    form.reset();
  };

  return (
    <Dialog open={!!user} onOpenChange={onClose}>
      <DialogContent className="bg-[rgb(var(--community-card))] border-[rgb(var(--community-border))]">
        <DialogHeader>
          <DialogTitle className="text-community-primary">Rejeitar Usuário</DialogTitle>
          <DialogDescription className="text-community-secondary">
            Forneça um motivo para a rejeição de {user?.name}. O usuário receberá uma notificação com este motivo.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="reason"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-community-primary">Motivo da Rejeição</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Ex: Informações incompletas, não atende aos critérios..."
                      {...field}
                      className="input-community"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose} className="border-[rgb(var(--community-border))] text-community-primary hover:bg-[rgb(var(--community-card-hover))]">
                Cancelar
              </Button>
              <Button type="submit" variant="destructive" disabled={isLoading} className="bg-red-600 hover:bg-red-700 text-white">
                {isLoading ? 'Rejeitando...' : 'Rejeitar Usuário'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
