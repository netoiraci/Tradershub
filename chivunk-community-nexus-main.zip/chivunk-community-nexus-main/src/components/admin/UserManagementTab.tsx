import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { UserPlus, Edit, Shield, ShieldOff, Search } from 'lucide-react';
import { formatDate } from '@/utils/adminUtils';
import { CreateUserDialog } from './CreateUserDialog';
import { EditUserDialog } from './EditUserDialog';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';

interface User {
  id: string;
  name: string | null;
  status: string;
  created_at: string;
  bio: string | null;
  is_admin: boolean;
}

interface UserManagementTabProps {
  allUsers: User[];
  loadingAllUsers: boolean;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  statusFilter: string;
  setStatusFilter: (filter: string) => void;
  onCreateUser: (data: { name: string; email: string; password: string; bio?: string, reason?: string }) => void;
  onEditUser: (userId: string, data: { name: string; bio?: string }) => void;
  onPromoteUser: (data: { userId: string, reason?: string }) => void;
  onDemoteUser: (data: { userId: string, reason?: string }) => void;
  createUserPending: boolean;
  editUserPending: boolean;
  promotePending: boolean;
  demotePending: boolean;
  currentUserId?: string;
}

export function UserManagementTab({
  allUsers,
  loadingAllUsers,
  searchTerm,
  setSearchTerm,
  statusFilter,
  setStatusFilter,
  onCreateUser,
  onEditUser,
  onPromoteUser,
  onDemoteUser,
  createUserPending,
  editUserPending,
  promotePending,
  demotePending,
  currentUserId
}: UserManagementTabProps) {
  const [showCreateUserModal, setShowCreateUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  // New: dialogs for reason on promote/demote
  const [showPromoteDialog, setShowPromoteDialog] = useState<{ open: boolean, user: User | null }>({ open: false, user: null });
  const [showDemoteDialog, setShowDemoteDialog] = useState<{ open: boolean, user: User | null }>({ open: false, user: null });
  const [reason, setReason] = useState("");
  const [createReason, setCreateReason] = useState(""); // For manual create user

  // New: Reason prompt for promote/demote
  function openPromoteDialog(user: User) {
    setReason("");
    setShowPromoteDialog({ open: true, user });
  }
  function openDemoteDialog(user: User) {
    setReason("");
    setShowDemoteDialog({ open: true, user });
  }
  function handlePromote() {
    if (showPromoteDialog.user)
      onPromoteUser({ userId: showPromoteDialog.user.id, reason });
    setShowPromoteDialog({ open: false, user: null });
    setReason("");
  }
  function handleDemote() {
    if (showDemoteDialog.user)
      onDemoteUser({ userId: showDemoteDialog.user.id, reason });
    setShowDemoteDialog({ open: false, user: null });
    setReason("");
  }
  // Adapting create user flow to capture reason
  function handleCreateUser(data: { name: string; email: string; password: string; bio?: string }) {
    onCreateUser({ ...data, reason: createReason });
    setShowCreateUserModal(false);
    setCreateReason("");
  }

  const handleEditUser = (data: { name: string; bio?: string }) => {
    if (editingUser) {
      onEditUser(editingUser.id, data);
      setEditingUser(null);
    }
  };

  return (
    <>
      <Card className="community-card border-[rgb(var(--community-border))]">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-community-primary">Gerenciar Usuários</CardTitle>
            <Button 
              onClick={() => setShowCreateUserModal(true)}
              className="bg-[rgb(var(--community-accent))] hover:bg-[rgb(var(--community-accent))]/90 text-white"
            >
              <UserPlus className="w-4 h-4 mr-2" />
              Criar Usuário
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filtros */}
          <div className="flex space-x-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-community-muted" />
                <Input
                  placeholder="Buscar por nome..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 input-community"
                />
              </div>
            </div>
            <div className="w-48">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full p-2 bg-[rgb(var(--community-card))] border border-[rgb(var(--community-border))] rounded-md text-community-primary"
              >
                <option value="all">Todos os Status</option>
                <option value="pending">Pendentes</option>
                <option value="approved">Aprovados</option>
                <option value="rejected">Rejeitados</option>
              </select>
            </div>
          </div>

          {loadingAllUsers ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[rgb(var(--community-accent))]"></div>
            </div>
          ) : (
            <div className="space-y-4">
              {allUsers.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center justify-between p-4 border border-[rgb(var(--community-border))] rounded-lg bg-[rgb(var(--community-card))] hover:bg-[rgb(var(--community-card-hover))] transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <Avatar>
                      <AvatarFallback className="bg-[rgb(var(--community-accent))] text-white">
                        {user.name?.[0]?.toUpperCase() || '?'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center space-x-2">
                        <h4 className="font-medium text-community-primary">
                          {user.name || 'Nome não informado'}
                        </h4>
                        {user.is_admin && (
                          <Badge variant="outline" className="text-blue-400 border-blue-400 bg-blue-400/10">
                            Admin
                          </Badge>
                        )}
                        <Badge 
                          variant={user.status === 'approved' ? 'default' : 
                                 user.status === 'pending' ? 'secondary' : 'destructive'}
                          className={
                            user.status === 'approved' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                            user.status === 'pending' ? 'bg-orange-500/20 text-orange-400 border-orange-500/30' :
                            'bg-red-500/20 text-red-400 border-red-500/30'
                          }
                        >
                          {user.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-community-secondary">
                        {user.bio || 'Nenhuma biografia'}
                      </p>
                      <p className="text-xs text-community-secondary">
                        Registrado em: {formatDate(user.created_at)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setEditingUser(user)}
                      className="border-[rgb(var(--community-border))] text-community-primary hover:bg-[rgb(var(--community-card-hover))]"
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Editar
                    </Button>
                    {user.status === 'approved' && (
                      user.is_admin ? (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openDemoteDialog(user)}
                          disabled={demotePending || user.id === currentUserId}
                          className="text-orange-400 border-orange-400 hover:bg-orange-400/10"
                        >
                          <ShieldOff className="w-4 h-4 mr-1" />
                          Remover Admin
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openPromoteDialog(user)}
                          disabled={promotePending}
                          className="text-blue-400 border-blue-400 hover:bg-blue-400/10"
                        >
                          <Shield className="w-4 h-4 mr-1" />
                          Promover Admin
                        </Button>
                      )
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      {/* Create user dialog (with new reason textarea) */}
      <CreateUserDialog
        open={showCreateUserModal}
        onClose={() => setShowCreateUserModal(false)}
        onCreateUser={handleCreateUser}
        isLoading={createUserPending}
      >
        <div className="mt-2">
          <Textarea
            placeholder="Opcional: informe o motivo para criação deste usuário"
            value={createReason}
            onChange={(e) => setCreateReason(e.target.value)}
            className="input-community"
          />
        </div>
      </CreateUserDialog>
      {/* Edit user dialog unchanged */}
      <EditUserDialog
        user={editingUser}
        onClose={() => setEditingUser(null)}
        onEditUser={handleEditUser}
        isLoading={editUserPending}
      />
      {/* Promote dialog */}
      <Dialog open={showPromoteDialog.open} onOpenChange={o => setShowPromoteDialog({ open: o, user: o ? showPromoteDialog.user : null })}>
        <DialogContent className="bg-[rgb(var(--community-card))] border-[rgb(var(--community-border))]">
          <DialogHeader>
            <DialogTitle className="text-community-primary">Promover usuário a Admin</DialogTitle>
            <DialogDescription className="text-community-secondary">Insira um motivo para esta promoção (opcional):</DialogDescription>
          </DialogHeader>
          <Textarea
            placeholder="Motivo para promoção (opcional)"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="input-community"
          />
          <DialogFooter>
            <Button onClick={handlePromote} className="bg-[rgb(var(--community-accent))] text-white">
              Confirmar Promoção
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Demote dialog */}
      <Dialog open={showDemoteDialog.open} onOpenChange={o => setShowDemoteDialog({ open: o, user: o ? showDemoteDialog.user : null })}>
        <DialogContent className="bg-[rgb(var(--community-card))] border-[rgb(var(--community-border))]">
          <DialogHeader>
            <DialogTitle className="text-community-primary">Remover privilégios de Admin</DialogTitle>
            <DialogDescription className="text-community-secondary">Insira um motivo para esta remoção (opcional):</DialogDescription>
          </DialogHeader>
          <Textarea
            placeholder="Motivo para remoção (opcional)"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="input-community"
          />
          <DialogFooter>
            <Button onClick={handleDemote} className="bg-orange-400 text-white">
              Confirmar Remoção
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
