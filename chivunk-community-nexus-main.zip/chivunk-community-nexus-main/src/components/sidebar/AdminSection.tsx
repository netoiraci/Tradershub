import { NavLink } from 'react-router-dom';
import { Shield, Bell } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';

interface AdminSectionProps {
  isAdmin: boolean;
}

export function AdminSection({ isAdmin }: AdminSectionProps) {
  // Reforçar: se não é admin, não mostra nada
  if (!isAdmin) {
    return null;
  }

  // Buscar contagem de usuários pendentes
  const { data: pendingCount = 0 } = useQuery({
    queryKey: ['pending-users-count'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('id', { count: 'exact' })
        .eq('status', 'pending');

      if (error) throw error;
      return data?.length || 0;
    },
    enabled: isAdmin,
    refetchInterval: 30000, // Atualizar a cada 30 segundos
  });

  return (
    <div>
      <h3 className="text-xs font-semibold text-community-secondary uppercase tracking-wide mb-2">
        Administração
      </h3>
      <div className="space-y-1">
        <NavLink
          to="/admin"
          className={({ isActive }) => `
            flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-200 text-sm relative
            ${isActive ? 'bg-[rgb(var(--community-card))] text-[rgb(var(--community-text-primary))] border border-[rgb(var(--community-border))] font-semibold' : 'text-[rgb(var(--community-text-secondary))] hover:text-[rgb(var(--community-text-primary))] hover:bg-[rgb(var(--community-card-hover))] font-medium'}
          `}
        >
          <Shield className="w-4 h-4 flex-shrink-0" />
          <span className="truncate">Painel Admin</span>
          {pendingCount > 0 && (
            <Badge 
              variant="destructive" 
              className="ml-auto h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs animate-pulse"
            >
              {pendingCount > 99 ? '99+' : pendingCount}
            </Badge>
          )}
        </NavLink>
      </div>
    </div>
  );
}
