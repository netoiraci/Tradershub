
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface MobileMenuButtonProps {
  isCollapsed: boolean;
  onToggle: () => void;
}

export function MobileMenuButton({ isCollapsed, onToggle }: MobileMenuButtonProps) {
  return (
    <Button
      onClick={onToggle}
      className="lg:hidden fixed top-6 left-6 z-50 btn-community-primary"
      size="sm"
    >
      {isCollapsed ? <Menu className="w-4 h-4" /> : <X className="w-4 h-4" />}
    </Button>
  );
}
