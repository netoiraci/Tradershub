
import { NavLink } from 'react-router-dom';
import { LucideIcon } from 'lucide-react';

interface NavigationItem {
  name: string;
  href: string;
  icon: LucideIcon;
  highlight?: boolean;
}

interface NavigationSectionProps {
  title: string;
  items: NavigationItem[];
  searchTerm: string;
}

export function NavigationSection({ title, items, searchTerm }: NavigationSectionProps) {
  const filteredItems = items.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (filteredItems.length === 0) {
    return null;
  }

  return (
    <div>
      <h3 className="text-xs font-semibold text-community-secondary uppercase tracking-wide mb-2">
        {title}
      </h3>
      <div className="space-y-1">
        {filteredItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.href}
            className={({ isActive }) => `
              flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-200 text-sm
              ${isActive ? 'bg-[rgb(var(--community-card))] text-[rgb(var(--community-text-primary))] border border-[rgb(var(--community-border))] font-semibold' : 'text-[rgb(var(--community-text-secondary))] hover:text-[rgb(var(--community-text-primary))] hover:bg-[rgb(var(--community-card-hover))] font-medium'}
              ${item.highlight ? 'border-2 border-[rgb(var(--community-accent))]/30' : ''}
            `}
          >
            <item.icon className="w-4 h-4 flex-shrink-0" />
            <span className="truncate">{item.name}</span>
            {item.highlight && (
              <span className="ml-auto text-xs bg-[rgb(var(--community-accent))] text-white px-2 py-0.5 rounded-full">
                Novo
              </span>
            )}
          </NavLink>
        ))}
      </div>
    </div>
  );
}
