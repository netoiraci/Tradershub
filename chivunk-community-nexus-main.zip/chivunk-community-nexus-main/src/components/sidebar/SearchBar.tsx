
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

interface SearchBarProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
}

export function SearchBar({ searchTerm, onSearchChange }: SearchBarProps) {
  return (
    <div className="p-6">
      <div className="relative">
        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-4 h-4 text-community-muted" />
        <Input
          placeholder="Buscar espaços..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="input-community pl-12 bg-[rgb(var(--community-card))] border-[rgb(var(--community-border))] rounded-full"
        />
      </div>
    </div>
  );
}
