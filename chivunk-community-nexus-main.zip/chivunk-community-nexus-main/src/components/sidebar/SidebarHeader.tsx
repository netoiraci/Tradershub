
import { TrendingUp } from 'lucide-react';

export function SidebarHeader() {
  return (
    <div className="p-6 border-b border-[rgb(var(--community-border))]">
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 bg-[rgb(var(--community-accent))] rounded-xl flex items-center justify-center">
          <TrendingUp className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-semibold text-community-primary">Trading Community</h1>
          <p className="text-xs text-community-secondary">Traders Unidos</p>
        </div>
      </div>
    </div>
  );
}
