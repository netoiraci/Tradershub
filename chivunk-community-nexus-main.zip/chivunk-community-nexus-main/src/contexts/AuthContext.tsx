
import { createContext, useContext, useEffect, useState } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { useUpdatePresence } from '@/hooks/useUserPresence';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  showWelcomeModal: boolean;
  setShowWelcomeModal: (show: boolean) => void;
  signUp: (email: string, password: string, name: string) => Promise<any>;
  signIn: (email: string, password: string) => Promise<any>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [showWelcomeModal, setShowWelcomeModal] = useState(false);
  const updatePresence = useUpdatePresence();

  // Gerenciar presença do usuário
  useEffect(() => {
    if (!user) return;

    // Atualizar presença inicial
    updatePresence.mutate({ status: 'online' });

    // Interval para manter presença ativa
    const interval = setInterval(() => {
      updatePresence.mutate({ status: 'online' });
    }, 2 * 60 * 1000); // A cada 2 minutos

    // Detectar inatividade
    let inactivityTimer: NodeJS.Timeout;
    
    const resetInactivityTimer = () => {
      clearTimeout(inactivityTimer);
      updatePresence.mutate({ status: 'online' });
      
      inactivityTimer = setTimeout(() => {
        updatePresence.mutate({ status: 'away' });
      }, 5 * 60 * 1000); // 5 minutos = away
    };

    // Eventos de atividade
    const activityEvents = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    activityEvents.forEach(event => {
      document.addEventListener(event, resetInactivityTimer, true);
    });

    resetInactivityTimer();

    // Cleanup
    return () => {
      clearInterval(interval);
      clearTimeout(inactivityTimer);
      activityEvents.forEach(event => {
        document.removeEventListener(event, resetInactivityTimer, true);
      });
      updatePresence.mutate({ status: 'offline' });
    };
  }, [user, updatePresence]);

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log('Auth state changed:', event, session);
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);

        // Check if user just signed in and show welcome modal
        if (event === 'SIGNED_IN' && session?.user) {
          checkAndShowWelcomeModal(session.user.id);
        }
        
        // Marcar como offline ao fazer logout
        if (event === 'SIGNED_OUT') {
          updatePresence.mutate({ status: 'offline' });
        }
      }
    );

    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      console.log('Initial session:', session);
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const checkAndShowWelcomeModal = async (userId: string) => {
    try {
      // Check if user profile is approved
      const { data: profile } = await supabase
        .from('profiles')
        .select('status, created_at')
        .eq('id', userId)
        .single();

      // Show welcome modal for approved users who just signed in
      if (profile?.status === 'approved') {
        const createdAt = new Date(profile.created_at);
        const now = new Date();
        const timeDiff = now.getTime() - createdAt.getTime();
        const hoursDiff = timeDiff / (1000 * 3600);

        // Show welcome modal if account was created in the last 24 hours
        if (hoursDiff < 24) {
          setShowWelcomeModal(true);
        }
      }
    } catch (error) {
      console.error('Error checking welcome modal:', error);
    }
  };

  const signUp = async (email: string, password: string, name: string) => {
    const redirectUrl = `${window.location.origin}/`;
    
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl,
        data: {
          name: name
        }
      }
    });

    console.log('SignUp result:', { data, error });
    return { data, error };
  };

  const signIn = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    console.log('SignIn result:', { data, error });
    return { data, error };
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      session,
      loading,
      showWelcomeModal,
      setShowWelcomeModal,
      signUp,
      signIn,
      signOut
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
