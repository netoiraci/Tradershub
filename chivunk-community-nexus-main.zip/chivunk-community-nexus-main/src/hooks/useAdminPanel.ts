import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

interface PendingUser {
  id: string;
  name: string | null;
  created_at: string;
  status: string;
}

interface AdminLog {
  id: string;
  action: string;
  details: any;
  created_at: string;
  admin_id: string;
  target_user_id: string | null;
}

interface User {
  id: string;
  name: string | null;
  status: string;
  created_at: string;
  bio: string | null;
  is_admin: boolean;
}

export function useAdminPanel() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Buscar usuários pendentes
  const { data: pendingUsers = [], isLoading: loadingUsers } = useQuery({
    queryKey: ['pending-users'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, name, created_at, status')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as PendingUser[];
    }
  });

  // Buscar todos os usuários para gerenciamento
  const { data: allUsers = [], isLoading: loadingAllUsers } = useQuery({
    queryKey: ['all-users', searchTerm, statusFilter],
    queryFn: async () => {
      let query = supabase
        .from('profiles')
        .select('id, name, status, created_at, bio')
        .order('created_at', { ascending: false });

      if (searchTerm) {
        query = query.ilike('name', `%${searchTerm}%`);
      }

      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }

      const { data: profilesData, error: profilesError } = await query;
      if (profilesError) throw profilesError;

      const { data: rolesData, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id, role')
        .eq('role', 'admin');

      if (rolesError) {
        console.error('Error fetching roles:', rolesError);
      }

      const adminUserIds = new Set(rolesData?.map(role => role.user_id) || []);

      return profilesData.map(profile => ({
        id: profile.id,
        name: profile.name,
        status: profile.status,
        created_at: profile.created_at,
        bio: profile.bio,
        is_admin: adminUserIds.has(profile.id)
      })) as User[];
    }
  });

  // Buscar logs administrativos
  const { data: adminLogs = [], isLoading: loadingLogs } = useQuery({
    queryKey: ['admin-logs'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('admin_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      return data as AdminLog[];
    }
  });

  // Buscar estatísticas
  const { data: stats } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: async () => {
      const { data: allUsersData, error: usersError } = await supabase
        .from('profiles')
        .select('status');

      if (usersError) throw usersError;

      const { data: adminRoles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id')
        .eq('role', 'admin');

      if (rolesError) throw rolesError;

      const pending = allUsersData.filter(u => u.status === 'pending').length;
      const approved = allUsersData.filter(u => u.status === 'approved').length;
      const rejected = allUsersData.filter(u => u.status === 'rejected').length;
      const admins = adminRoles.length;

      return { pending, approved, rejected, admins, total: allUsersData.length };
    }
  });

  const invalidateQueries = () => {
    queryClient.invalidateQueries({ queryKey: ['pending-users'] });
    queryClient.invalidateQueries({ queryKey: ['all-users'] });
    queryClient.invalidateQueries({ queryKey: ['admin-logs'] });
    queryClient.invalidateQueries({ queryKey: ['admin-stats'] });
  };

  // Aprovar usuário
  const approveUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const { error } = await supabase.rpc('approve_user', {
        target_user_id: userId,
        admin_user_id: user?.id
      });

      if (error) throw error;
    },
    onSuccess: () => {
      invalidateQueries();
      toast({
        title: "Usuário aprovado",
        description: "O usuário foi aprovado com sucesso e recebeu uma notificação.",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao aprovar usuário",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });
    }
  });

  // Rejeitar usuário
  const rejectUserMutation = useMutation({
    mutationFn: async ({ userId, reason }: { userId: string; reason?: string }) => {
      const { error } = await supabase.rpc('reject_user', {
        target_user_id: userId,
        admin_user_id: user?.id,
        reason: reason || 'Não especificado'
      });

      if (error) throw error;
    },
    onSuccess: () => {
      invalidateQueries();
      toast({
        title: "Usuário rejeitado",
        description: "O usuário foi rejeitado e recebeu uma notificação com o motivo.",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao rejeitar usuário",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });
    }
  });

  // Promover a admin (now accepts reason)
  const promoteUserMutation = useMutation({
    mutationFn: async ({ userId, reason }: { userId: string; reason?: string }) => {
      const { error } = await supabase.rpc('promote_to_admin', {
        target_user_id: userId,
        admin_user_id: user?.id,
        reason: reason || null
      });
      if (error) throw error;
    },
    onSuccess: () => {
      invalidateQueries();
      toast({
        title: "Usuário promovido",
        description: "O usuário foi promovido a administrador e recebeu uma notificação.",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao promover usuário",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });
    }
  });

  // Demote from admin (now accepts reason)
  const demoteUserMutation = useMutation({
    mutationFn: async ({ userId, reason }: { userId: string; reason?: string }) => {
      const { error } = await supabase.rpc('demote_from_admin', {
        target_user_id: userId,
        admin_user_id: user?.id,
        reason: reason || null
      });
      if (error) throw error;
    },
    onSuccess: () => {
      invalidateQueries();
      toast({
        title: "Privilégios removidos",
        description: "Os privilégios de administrador foram removidos e o usuário foi notificado.",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao remover privilégios",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });
    }
  });

  // Criar usuário manualmente (now accepts reason)
  const createUserMutation = useMutation({
    mutationFn: async (formData: {
      name: string;
      email: string;
      password: string;
      bio?: string;
      reason?: string;
    }) => {
      const { error } = await supabase.rpc('create_user_manually', {
        user_email: formData.email,
        user_name: formData.name,
        user_password: formData.password,
        admin_user_id: user?.id,
        reason: formData.reason || null
      });
      if (error) throw error;
    },
    onSuccess: () => {
      invalidateQueries();
      toast({
        title: "Usuário criado",
        description: "O usuário foi criado com sucesso.",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao criar usuário",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });
    }
  });

  // Editar usuário
  const editUserMutation = useMutation({
    mutationFn: async ({ userId, formData }: { 
      userId: string; 
      formData: { name: string; bio?: string; }
    }) => {
      const { error } = await supabase
        .from('profiles')
        .update({
          name: formData.name,
          bio: formData.bio
        })
        .eq('id', userId);

      if (error) throw error;
    },
    onSuccess: () => {
      invalidateQueries();
      toast({
        title: "Usuário atualizado",
        description: "Os dados do usuário foram atualizados com sucesso.",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao editar usuário",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });
    }
  });

  return {
    // Data
    pendingUsers,
    allUsers,
    adminLogs,
    stats,
    
    // Loading states
    loadingUsers,
    loadingAllUsers,
    loadingLogs,
    
    // Filters
    searchTerm,
    setSearchTerm,
    statusFilter,
    setStatusFilter,
    
    // Mutations
    approveUserMutation,
    rejectUserMutation,
    promoteUserMutation,
    demoteUserMutation,
    createUserMutation,
    editUserMutation,
  };
}
