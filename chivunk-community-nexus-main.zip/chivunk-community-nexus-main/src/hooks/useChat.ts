
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useEffect } from 'react';

export interface ChatRoom {
  id: string;
  name: string;
  description: string | null;
  is_public: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface ChatMessage {
  id: string;
  room_id: string;
  user_id: string;
  content: string;
  message_type: string;
  created_at: string;
  updated_at: string;
  deleted: boolean;
  profiles?: {
    name: string | null;
  };
}

export interface ChatParticipant {
  id: string;
  room_id: string;
  user_id: string;
  joined_at: string;
  is_admin: boolean;
}

// Hook para buscar salas de chat
export function useChatRooms() {
  return useQuery({
    queryKey: ['chat-rooms'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('chat_rooms')
        .select('*')
        .eq('is_public', true)
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      return data as ChatRoom[];
    }
  });
}

// Hook para buscar mensagens de uma sala
export function useChatMessages(roomId: string) {
  return useQuery({
    queryKey: ['chat-messages', roomId],
    queryFn: async () => {
      // First get the messages
      const { data: messagesData, error: messagesError } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('room_id', roomId)
        .eq('deleted', false)
        .order('created_at', { ascending: true });

      if (messagesError) throw messagesError;

      // Get unique user IDs from messages
      const userIds = [...new Set(messagesData.map(msg => msg.user_id))];
      
      // Get profiles for these users
      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('id, name')
        .in('id', userIds);

      if (profilesError) throw profilesError;

      // Create a map of user_id to profile
      const profilesMap = new Map(profilesData.map(profile => [profile.id, profile]));

      // Combine messages with profiles
      const messagesWithProfiles = messagesData.map(message => ({
        ...message,
        profiles: profilesMap.get(message.user_id) || { name: null }
      }));

      return messagesWithProfiles as ChatMessage[];
    },
    enabled: !!roomId
  });
}

// Hook para enviar mensagem
export function useSendMessage() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ roomId, content }: { roomId: string; content: string }) => {
      if (!user) throw new Error('User not authenticated');
      
      const { error } = await supabase
        .from('chat_messages')
        .insert([{
          room_id: roomId,
          user_id: user.id,
          content,
          message_type: 'text',
          deleted: false
        }]);
      
      if (error) throw error;
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['chat-messages', variables.roomId] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao enviar mensagem",
        description: error.message || "Tente novamente",
        variant: "destructive"
      });
    }
  });
}

// Hook para participar de uma sala
export function useJoinRoom() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ roomId }: { roomId: string }) => {
      if (!user) throw new Error('User not authenticated');
      
      const { error } = await supabase
        .from('chat_participants')
        .insert([{
          room_id: roomId,
          user_id: user.id,
          is_admin: false
        }]);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chat-rooms'] });
      toast({
        title: "Conectado ao chat",
        description: "Você entrou na sala de chat."
      });
    },
    onError: (error: any) => {
      // Se o erro for de duplicação, significa que já está na sala - não mostrar erro
      if (!error.message.includes('duplicate')) {
        toast({
          title: "Erro ao entrar na sala",
          description: error.message || "Tente novamente",
          variant: "destructive"
        });
      }
    }
  });
}

// Hook para realtime - escutar novas mensagens
export function useChatRealtime(roomId: string) {
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!roomId) return;

    const channel = supabase
      .channel(`chat-messages-${roomId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `room_id=eq.${roomId}`
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['chat-messages', roomId] });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'chat_messages',
          filter: `room_id=eq.${roomId}`
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['chat-messages', roomId] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [roomId, queryClient]);
}
