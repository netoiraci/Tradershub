
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

export interface Post {
  id: string;
  title: string;
  content: string;
  category: string | null;
  section: string;
  likes_count: number;
  comments_count: number;
  shares_count: number;
  created_at: string;
  user_id: string;
  deleted?: boolean;
  profiles: {
    name: string | null;
  } | null;
}

export function usePosts(section?: string) {
  return useQuery({
    queryKey: ['posts', section],
    queryFn: async () => {
      // Ajuste: Remover join direto com profiles e fazer subselect manual do nome
      let query = supabase
        .from('posts')
        .select(`
          id,
          title,
          content,
          category,
          section,
          likes_count,
          comments_count,
          shares_count,
          created_at,
          user_id,
          deleted
        `)
        .eq('deleted', false)
        .order('created_at', { ascending: false });

      if (section) {
        query = query.eq('section', section);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching posts:', error);
        throw error;
      }

      // Buscar nomes via subquery manual para cada post
      // Prefetch dos users_ids únicos
      const userIds = [...new Set((data || []).map((post: any) => post.user_id))].filter(Boolean);

      let profilesMap: Record<string, { name: string | null }> = {};

      if (userIds.length > 0) {
        const { data: profilesData, error: profilesError } = await supabase
          .from('profiles')
          .select('id, name')
          .in('id', userIds);

        if (!profilesError && profilesData) {
          for (const profile of profilesData) {
            profilesMap[profile.id] = { name: profile.name || null };
          }
        }
      }

      const mappedPosts: Post[] = (data || []).map((post: any) => ({
        id: post.id,
        title: post.title,
        content: post.content,
        category: post.category,
        section: post.section,
        likes_count: post.likes_count,
        comments_count: post.comments_count,
        shares_count: post.shares_count,
        created_at: post.created_at,
        user_id: post.user_id,
        deleted: post.deleted,
        profiles: profilesMap[post.user_id] || null
      }));

      return mappedPosts;
    }
  });
}

export function useCreatePost() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ title, content, section, category }: {
      title: string;
      content: string;
      section: string;
      category?: string;
    }) => {
      if (!user) throw new Error('User not authenticated');

      console.log('Creating post:', { title, content, section, category, user_id: user.id });

      const { data, error } = await supabase
        .from('posts')
        .insert([{
          title,
          content,
          section,
          category,
          user_id: user.id
        }])
        .select()
        .single();

      if (error) {
        console.error('Error creating post:', error);
        throw error;
      }

      console.log('Created post:', data);
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      toast({
        title: "Post criado com sucesso!",
        description: "Seu post foi compartilhado com a comunidade."
      });
    },
    onError: (error: any) => {
      console.error('Create post error:', error);
      toast({
        title: "Erro ao criar post",
        description: error.message || "Tente novamente",
        variant: "destructive"
      });
    }
  });
}

// Nova mutation para deletar post (soft delete)
export function useDeletePost() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (postId: string) => {
      if (!user) throw new Error('User not authenticated');
      const { error } = await supabase
        .from('posts')
        .update({ deleted: true })
        .eq('id', postId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      toast({
        title: "Post excluído",
        description: "O post foi removido do feed (soft-deleted)."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao excluir post",
        description: error.message || "Tente novamente",
        variant: "destructive"
      });
    }
  });
}

// Nova mutation para deletar comentário (soft delete)
export function useDeleteComment() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (commentId: string) => {
      if (!user) throw new Error('User not authenticated');
      const { error } = await supabase
        .from('comments')
        .update({ deleted: true })
        .eq('id', commentId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['comments'] });
      toast({
        title: "Comentário excluído",
        description: "O comentário foi removido (soft-deleted)."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao excluir comentário",
        description: error.message || "Tente novamente",
        variant: "destructive"
      });
    }
  });
}
