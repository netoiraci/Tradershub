
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

export interface Comment {
  id: string;
  post_id: string;
  author_id: string;
  parent_id: string | null;
  content: string;
  created_at: string;
  deleted: boolean;
  profiles?: {
    name?: string;
  };
  // children will be built on the frontend from a flat list
}

export function useComments(postId: string) {
  return useQuery({
    queryKey: ['comments', postId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('comments')
        .select('id, post_id, author_id, parent_id, content, created_at, deleted')
        .eq('post_id', postId)
        .eq('deleted', false) // only fetch active comments
        .order('created_at', { ascending: true });
      if (error) throw error;

      // Fetch profiles for comment authors
      const authorIds = [...new Set((data || []).map((comment: any) => comment.author_id))].filter(Boolean);
      
      let profilesMap: Record<string, { name: string | null }> = {};

      if (authorIds.length > 0) {
        const { data: profilesData, error: profilesError } = await supabase
          .from('profiles')
          .select('id, name')
          .in('id', authorIds);

        if (!profilesError && profilesData) {
          for (const profile of profilesData) {
            profilesMap[profile.id] = { name: profile.name || null };
          }
        }
      }

      const mappedComments: Comment[] = (data || []).map((comment: any) => ({
        id: comment.id,
        post_id: comment.post_id,
        author_id: comment.author_id,
        parent_id: comment.parent_id,
        content: comment.content,
        created_at: comment.created_at,
        deleted: comment.deleted,
        profiles: profilesMap[comment.author_id] || null
      }));

      return mappedComments;
    }
  });
}

export function useCreateComment() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ postId, parentId, content }: { postId: string, parentId?: string, content: string }) => {
      if (!user) throw new Error('User not authenticated');
      const { error } = await supabase
        .from('comments')
        .insert([{
          post_id: postId,
          author_id: user.id,
          parent_id: parentId ?? null,
          content,
          deleted: false
        }]);
      if (error) throw error;
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['comments', variables.postId] });
      queryClient.invalidateQueries({ queryKey: ['posts'] }); // Refresh post counts
      toast({
        title: "Comentário publicado",
        description: "Seu comentário foi adicionado."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao comentar",
        description: error.message || "Tente novamente",
        variant: "destructive"
      });
    }
  });
}

export function useDeleteComment() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async ({ commentId, postId }: { commentId: string, postId: string }) => {
      if (!user) throw new Error('User not authenticated');
      const { error } = await supabase
        .from('comments')
        .update({ deleted: true })
        .eq('id', commentId);
      if (error) throw error;
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['comments', variables.postId] });
      queryClient.invalidateQueries({ queryKey: ['posts'] }); // Refresh post counts
      toast({
        title: "Comentário excluído",
        description: "O comentário foi removido."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao excluir comentário",
        description: error.message || "Tente novamente",
        variant: "destructive"
      });
    }
  });
}
