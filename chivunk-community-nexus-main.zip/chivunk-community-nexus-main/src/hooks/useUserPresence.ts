
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useEffect } from 'react';

export interface UserPresence {
  id: string;
  user_id: string;
  room_id?: string;
  status: 'online' | 'away' | 'busy' | 'offline';
  last_seen: string;
  profiles?: {
    name: string | null;
    avatar_url: string | null;
  };
}

// Hook para buscar usuários online
export function useOnlineUsers(roomId?: string) {
  return useQuery({
    queryKey: ['online-users', roomId],
    queryFn: async () => {
      let query = supabase
        .from('user_presence')
        .select('*')
        .gte('last_seen', new Date(Date.now() - 5 * 60 * 1000).toISOString()) // Últimos 5 minutos
        .order('last_seen', { ascending: false });

      if (roomId) {
        query = query.or(`room_id.eq.${roomId},room_id.is.null`);
      } else {
        query = query.is('room_id', null);
      }

      const { data: presenceData, error: presenceError } = await query;
      
      if (presenceError) throw presenceError;

      // Get unique user IDs from presence data
      const userIds = [...new Set(presenceData.map(presence => presence.user_id))];
      
      // Get profiles for these users
      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('id, name, avatar_url')
        .in('id', userIds);

      if (profilesError) throw profilesError;

      // Create a map of user_id to profile
      const profilesMap = new Map(profilesData.map(profile => [profile.id, profile]));

      // Combine presence with profiles
      const presenceWithProfiles = presenceData.map(presence => ({
        ...presence,
        profiles: profilesMap.get(presence.user_id) || { name: null, avatar_url: null }
      }));

      return presenceWithProfiles as UserPresence[];
    },
    refetchInterval: 30000, // Atualizar a cada 30 segundos
  });
}

// Hook para atualizar presença do usuário
export function useUpdatePresence() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ 
      roomId, 
      status = 'online' 
    }: { 
      roomId?: string; 
      status?: 'online' | 'away' | 'busy' | 'offline' 
    }) => {
      if (!user) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('user_presence')
        .upsert({
          user_id: user.id,
          room_id: roomId || null,
          status,
          last_seen: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'user_id,room_id'
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['online-users'] });
    }
  });
}

// Hook para gerenciar presença automaticamente
export function usePresenceManager(roomId?: string) {
  const { user } = useAuth();
  const updatePresence = useUpdatePresence();

  useEffect(() => {
    if (!user) return;

    // Atualizar presença inicialmente
    updatePresence.mutate({ roomId, status: 'online' });

    // Atualizar presença a cada 2 minutos
    const interval = setInterval(() => {
      updatePresence.mutate({ roomId, status: 'online' });
    }, 2 * 60 * 1000);

    // Atualizar presença quando a página está being fechada
    const handleBeforeUnload = () => {
      updatePresence.mutate({ roomId, status: 'offline' });
    };

    // Detectar quando o usuário fica inativo
    let inactivityTimer: NodeJS.Timeout;
    
    const resetInactivityTimer = () => {
      clearTimeout(inactivityTimer);
      updatePresence.mutate({ roomId, status: 'online' });
      
      inactivityTimer = setTimeout(() => {
        updatePresence.mutate({ roomId, status: 'away' });
      }, 5 * 60 * 1000); // 5 minutos de inatividade = away
    };

    // Eventos para detectar atividade
    const activityEvents = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    activityEvents.forEach(event => {
      document.addEventListener(event, resetInactivityTimer, true);
    });

    resetInactivityTimer();

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      clearInterval(interval);
      clearTimeout(inactivityTimer);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      activityEvents.forEach(event => {
        document.removeEventListener(event, resetInactivityTimer, true);
      });
      
      // Marcar como offline ao sair
      updatePresence.mutate({ roomId, status: 'offline' });
    };
  }, [user, roomId]); // Removed updatePresence from dependencies to fix infinite loop
}
