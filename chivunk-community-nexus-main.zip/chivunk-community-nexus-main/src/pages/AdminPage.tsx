
import { CommunityLayout } from "@/components/CommunityLayout";
import { AdminPanel } from "@/components/AdminPanel";
import { useIsAdmin } from "@/hooks/useIsAdmin";

export default function AdminPage() {
  const { data: isAdmin, isLoading } = useIsAdmin();

  if (isLoading) {
    return (
      <CommunityLayout>
        <div className="flex flex-col items-center justify-center min-h-[60vh]">
          <div className="w-16 h-16 animate-spin rounded-full border-4 border-[rgb(var(--community-accent))] border-t-transparent mb-4"></div>
          <span className="text-community-primary">Verificando permissões...</span>
        </div>
      </CommunityLayout>
    );
  }

  if (!isAdmin) {
    return (
      <CommunityLayout>
        <div className="flex flex-col items-center justify-center min-h-[60vh]">
          <h2 className="text-2xl font-bold text-red-400 mb-4">Acesso Negado</h2>
          <p className="text-community-secondary">Você não tem permissão para acessar o painel administrativo.</p>
        </div>
      </CommunityLayout>
    );
  }

  return (
    <CommunityLayout>
      <AdminPanel />
    </CommunityLayout>
  );
}
