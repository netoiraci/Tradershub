
import React, { useState } from 'react';
import { CommunityLayout } from '@/components/CommunityLayout';
import { Chat } from '@/components/Chat';
import { ChatRoomList } from '@/components/ChatRoomList';
import { OnlineUsers } from '@/components/OnlineUsers';
import { MessageSquare, Users, Hash } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { usePresenceManager, useOnlineUsers } from '@/hooks/useUserPresence';

export default function ChatPage() {
  const [selectedRoom, setSelectedRoom] = useState<{ id: string; name: string } | null>(null);
  const { user } = useAuth();

  // Gerenciar presença automaticamente
  usePresenceManager(selectedRoom?.id);

  const handleRoomSelect = (roomId: string, roomName: string) => {
    setSelectedRoom({ id: roomId, name: roomName });
  };

  return (
    <CommunityLayout>
      <div className="space-y-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-community-accent to-community-primary rounded-xl flex items-center justify-center shadow-lg">
              <MessageSquare className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-community-primary">Chat da Comunidade</h1>
              <p className="text-community-secondary">Converse em tempo real com outros traders</p>
            </div>
          </div>
          
          {/* Stats rápidos */}
          <div className="flex items-center space-x-4 text-sm text-community-secondary">
            <div className="flex items-center space-x-1">
              <Users className="w-4 h-4" />
              <OnlineUsersCount />
            </div>
            {selectedRoom && (
              <div className="flex items-center space-x-1">
                <Hash className="w-4 h-4" />
                <span>{selectedRoom.name}</span>
              </div>
            )}
          </div>
        </div>

        {/* Chat Interface - Layout responsivo melhorado */}
        <div className="flex flex-col lg:grid lg:grid-cols-12 gap-4 h-[calc(100vh-200px)] min-h-[600px]">
          {/* Sidebar Esquerda - Lista de Salas */}
          <div className="lg:col-span-3 xl:col-span-3 order-1 lg:order-1">
            <div className="community-card h-full">
              <ChatRoomList
                selectedRoomId={selectedRoom?.id}
                onRoomSelect={handleRoomSelect}
              />
            </div>
          </div>

          {/* Área Principal do Chat */}
          <div className="lg:col-span-6 xl:col-span-6 order-2 lg:order-2">
            {selectedRoom ? (
              <Chat roomId={selectedRoom.id} roomName={selectedRoom.name} />
            ) : (
              <div className="h-full community-card border-community-border flex items-center justify-center">
                <div className="text-center max-w-md px-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-community-accent/20 to-community-primary/20 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <MessageSquare className="w-10 h-10 text-community-muted" />
                  </div>
                  <h3 className="text-xl font-semibold text-community-primary mb-3">
                    Selecione uma sala de chat
                  </h3>
                  <p className="text-community-secondary leading-relaxed mb-4">
                    Escolha uma sala de chat na barra lateral para começar a conversar com outros membros da comunidade.
                  </p>
                  <div className="flex items-center justify-center space-x-2 text-sm text-community-muted">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span>Sistema online</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar Direita - Usuários Online */}
          <div className="lg:col-span-3 xl:col-span-3 order-3 lg:order-3">
            <div className="community-card h-full">
              <OnlineUsers 
                roomId={selectedRoom?.id}
                currentUserId={user?.id}
              />
            </div>
          </div>
        </div>

        {/* Rodapé com informações adicionais */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-community-muted px-4 py-2 community-card border-community-border">
          <div className="flex items-center space-x-4">
            <span>Sistema de presença ativo</span>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span>Tempo real</span>
            </div>
          </div>
          <div className="text-right">
            <span>Atualização automática a cada 30s</span>
          </div>
        </div>
      </div>
    </CommunityLayout>
  );
}

// Componente para mostrar contagem de usuários online
function OnlineUsersCount() {
  const { data: onlineUsers = [] } = useOnlineUsers();
  return <span>{onlineUsers.length} online</span>;
}
