
import { CreatePostForm } from '../components/CreatePostForm';
import { PostCard } from '../components/PostCard';
import { CommunityLayout } from '../components/CommunityLayout';
import { CommunityStats } from '../components/CommunityStats';
import { WeeklyChallenges } from '../components/WeeklyChallenges';
import { WelcomeModal } from '../components/WelcomeModal';
import { usePosts } from '../hooks/usePosts';
import { useAuth } from '../contexts/AuthContext';
import { Navigate } from 'react-router-dom';

export default function FeedPage() {
  const { user, loading, showWelcomeModal, setShowWelcomeModal } = useAuth();
  const { data: posts = [], isLoading: postsLoading } = usePosts('Feed Principal');

  if (loading) {
    return (
      <div className="min-h-screen bg-[#121212] flex items-center justify-center">
        <div className="text-white">Carregando...</div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  return (
    <CommunityLayout>
      <div className="space-y-6">
        {/* Community Stats - Full Width */}
        <CommunityStats />

        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-3xl font-semibold text-community-primary">
            Feed da Comunidade Trading
          </h1>
          <p className="text-community-secondary max-w-4xl mx-auto">
            Últimas discussões, análises e estratégias compartilhadas pela comunidade
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
            {/* Create Post Form */}
            <CreatePostForm section="Feed Principal" />
            
            {/* Posts */}
            <div className="space-y-6">
              {postsLoading ? (
                <div className="text-center text-community-secondary py-8">
                  Carregando posts...
                </div>
              ) : posts.length === 0 ? (
                <div className="text-center text-community-secondary py-8">
                  Ainda não há posts. Seja o primeiro a compartilhar algo!
                </div>
              ) : (
                posts.map((post) => (
                  <PostCard
                    key={post.id}
                    id={post.id}
                    title={post.title}
                    content={post.content}
                    category={post.category}
                    section={post.section}
                    likes_count={post.likes_count}
                    comments_count={post.comments_count}
                    shares_count={post.shares_count}
                    created_at={post.created_at}
                    user_id={post.user_id}
                    profiles={post.profiles}
                  />
                ))
              )}
            </div>
          </div>

            {/* Sidebar */}
            <div className="lg:col-span-1 space-y-6">
            <WeeklyChallenges />
            </div>
          </div>
        </div>
      </div>

      {/* Welcome Modal */}
      <WelcomeModal 
        open={showWelcomeModal} 
        onClose={() => setShowWelcomeModal(false)} 
      />
    </CommunityLayout>
  );
}
