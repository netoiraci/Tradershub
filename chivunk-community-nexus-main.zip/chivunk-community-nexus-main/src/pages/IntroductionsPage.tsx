
import { useState } from 'react';
import { CommunityLayout } from '../components/CommunityLayout';
import { WelcomeMessage } from '../components/WelcomeMessage';
import { OnboardingTutorial } from '../components/OnboardingTutorial';
import { CreatePostForm } from '../components/CreatePostForm';
import { PostCard } from '../components/PostCard';
import { GameficationBadges } from '../components/GameficationBadges';
import { CommunityLeaderboard } from '../components/CommunityLeaderboard';
import { usePosts } from '../hooks/usePosts';
import { useAuth } from '../contexts/AuthContext';
import { Navigate } from 'react-router-dom';

export default function IntroductionsPage() {
  const { user, loading } = useAuth();
  const [showWelcome, setShowWelcome] = useState(true);
  const [showTutorial, setShowTutorial] = useState(false);
  const { data: posts = [], isLoading: postsLoading } = usePosts('Apresentações');

  const handleWelcomeClose = () => {
    setShowWelcome(false);
    setShowTutorial(true);
  };

  const handleTutorialComplete = () => {
    setShowTutorial(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#121212] flex items-center justify-center">
        <div className="text-white">Carregando...</div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  return (
    <CommunityLayout>
      <div className="space-y-6">
        {/* Welcome Message for new users */}
        {showWelcome && (
          <WelcomeMessage onClose={handleWelcomeClose} />
        )}

        {/* Onboarding Tutorial */}
        {showTutorial && (
          <OnboardingTutorial onComplete={handleTutorialComplete} />
        )}

        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl font-semibold text-community-primary mb-4">
            Apresentações da Comunidade
          </h1>
          <p className="text-community-secondary max-w-4xl mx-auto">
            Se apresente para a comunidade e conte sua jornada no trading
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
            {/* Create Post Form */}
            <CreatePostForm 
              section="Apresentações" 
              placeholder="Conte para a comunidade sobre sua trajetória no trading..."
            />
            
            {/* Posts */}
            <div className="space-y-6">
              {postsLoading ? (
                <div className="text-center text-community-secondary py-8">
                  Carregando apresentações...
                </div>
              ) : posts.length === 0 ? (
                <div className="text-center text-community-secondary py-8">
                  Ainda não há apresentações. Seja o primeiro a se apresentar!
                </div>
              ) : (
                posts.map((post) => (
                  <PostCard
                    key={post.id}
                    id={post.id}
                    title={post.title}
                    content={post.content}
                    category={post.category}
                    section={post.section}
                    likes_count={post.likes_count}
                    comments_count={post.comments_count}
                    shares_count={post.shares_count}
                    created_at={post.created_at}
                    user_id={post.user_id}
                    profiles={post.profiles}
                  />
                ))
              )}
            </div>
          </div>

            {/* Sidebar */}
            <div className="lg:col-span-1 space-y-6">
            <GameficationBadges />
            <CommunityLeaderboard />
            
            <div className="community-card p-6">
              <h3 className="text-lg font-semibold text-community-primary mb-4">
                💡 Dicas para uma boa apresentação
              </h3>
              <ul className="space-y-3 text-sm text-community-secondary">
                <li>• Conte sobre sua experiência no mercado</li>
                <li>• Mencione seus ativos favoritos</li>
                <li>• Compartilhe seus objetivos de trading</li>
                <li>• Fale sobre estratégias que usa</li>
                <li>• Seja autêntico e respeitoso</li>
              </ul>
            </div>
            </div>
          </div>
        </div>
      </div>
    </CommunityLayout>
  );
}
