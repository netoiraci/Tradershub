
import { useParams } from 'react-router-dom';
import { CommunityLayout } from '@/components/CommunityLayout';
import { CreatePostForm } from '@/components/CreatePostForm';
import { PostCard } from '@/components/PostCard';
import { usePosts } from '@/hooks/usePosts';
import { 
  TrendingUp, 
  Target, 
  BarChart3, 
  BookOpen, 
  Lightbulb, 
  Users,
  MessageSquare,
  Calendar,
  Video
} from 'lucide-react';

// Configuração dos espaços de trading
const tradingSpaces: Record<string, {
  title: string;
  icon: any;
  description: string;
  section: string;
}> = {
  'analise-tecnica': {
    title: 'Análise Técnica',
    icon: BarChart3,
    description: 'Análises de gráficos, indicadores e padrões de preço',
    section: 'analise-tecnica'
  },
  'estrategias': {
    title: 'Estratégias de Trading',
    icon: Target,
    description: 'Setups, métodos e sistemas de trading',
    section: 'estrategias'
  },
  'analise': {
    title: 'Análises de Mercado',
    icon: TrendingUp,
    description: 'Notícias, análise fundamentalista e sentimento de mercado',
    section: 'analise'
  },
  'historias': {
    title: 'Histórias & Cases',
    icon: BookOpen,
    description: 'Experiências, cases de sucesso e lições aprendidas',
    section: 'historias'
  },
  'ideias': {
    title: 'Ideias e Sugestões',
    icon: Lightbulb,
    description: 'Brainstorming e novas perspectivas de mercado',
    section: 'ideias'
  },
  'networking': {
    title: 'Networking',
    icon: Users,
    description: 'Conecte-se com outros traders da comunidade',
    section: 'networking'
  },
  'discussoes': {
    title: 'Discussões Gerais',
    icon: MessageSquare,
    description: 'Discussões gerais sobre trading e mercados',
    section: 'discussoes'
  },
  'agenda': {
    title: 'Agenda de Eventos',
    icon: Calendar,
    description: 'Webinars, lives e encontros da comunidade',
    section: 'agenda'
  },
  'videochamadas': {
    title: 'Videochamadas',
    icon: Video,
    description: 'Salas de estudo e discussão ao vivo',
    section: 'videochamadas'
  }
};

export default function TradingSpacePage() {
  const { space } = useParams<{ space: string }>();
  
  console.log('URL space parameter:', space);
  
  // Verificar se o espaço existe na configuração
  const spaceConfig = space && tradingSpaces[space] ? tradingSpaces[space] : null;

  console.log('Space config found:', spaceConfig);

  if (!spaceConfig) {
    return (
      <CommunityLayout>
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold text-community-primary mb-4">
            Espaço não encontrado
          </h1>
          <p className="text-community-secondary">
            O espaço de trading solicitado não existe. (Parâmetro recebido: "{space}")
          </p>
        </div>
      </CommunityLayout>
    );
  }

  const { data: posts = [], isLoading } = usePosts(spaceConfig.section);

  console.log('Posts for section:', spaceConfig.section, 'Count:', posts.length);

  return (
    <CommunityLayout>
      <div className="space-y-6 max-w-6xl mx-auto">
        {/* Header do espaço */}
        <div className="flex items-center space-x-4 mb-6">
          <div className="w-12 h-12 bg-[rgb(var(--community-accent))] rounded-xl flex items-center justify-center">
            <spaceConfig.icon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-community-primary">
              {spaceConfig.title}
            </h1>
            <p className="text-community-secondary">
              {spaceConfig.description}
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3">
            {/* Formulário de criação de post */}
            <CreatePostForm section={spaceConfig.section} />

            {/* Lista de posts */}
            <div className="space-y-6 mt-6">
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="animate-pulse">
                      <div className="h-40 bg-[rgb(var(--community-card))] rounded-xl"></div>
                    </div>
                  ))}
                </div>
              ) : posts.length === 0 ? (
                <div className="text-center py-12 community-card">
                  <spaceConfig.icon className="w-16 h-16 text-[rgb(var(--community-border))] mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-community-primary mb-2">
                    Ainda não há posts neste espaço
                  </h3>
                  <p className="text-community-secondary">
                    Seja o primeiro a compartilhar algo sobre {spaceConfig.title.toLowerCase()}!
                  </p>
                </div>
              ) : (
                posts.map((post) => (
                  <PostCard 
                    key={post.id} 
                    id={post.id}
                    title={post.title}
                    content={post.content}
                    category={post.category}
                    section={post.section}
                    likes_count={post.likes_count}
                    comments_count={post.comments_count}
                    shares_count={post.shares_count}
                    created_at={post.created_at}
                    user_id={post.user_id}
                    profiles={post.profiles}
                  />
                ))
              )}
            </div>
          </div>

          {/* Sidebar informativa */}
          <div className="lg:col-span-1">
            <div className="community-card p-6 sticky top-6">
              <h3 className="text-lg font-semibold text-community-primary mb-4">
                📊 Sobre este espaço
              </h3>
              <p className="text-sm text-community-secondary mb-4">
                {spaceConfig.description}
              </p>
              <div className="text-xs text-community-secondary">
                <p className="mb-2">• Compartilhe conhecimento</p>
                <p className="mb-2">• Faça perguntas relevantes</p>
                <p className="mb-2">• Respeite outros membros</p>
                <p>• Mantenha o foco no tema</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </CommunityLayout>
  );
}
