import { 
  CheckCircle, 
  XCircle, 
  Shield, 
  ShieldOff, 
  UserPlus, 
  Activity 
} from 'lucide-react';

export const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleString('pt-BR');
};

export const getActionIcon = (action: string) => {
  switch (action) {
    case 'approve_user':
      return { Icon: CheckCircle, className: "w-4 h-4 text-green-400" };
    case 'reject_user':
      return { Icon: XCircle, className: "w-4 h-4 text-red-400" };
    case 'promote_to_admin':
      return { Icon: Shield, className: "w-4 h-4 text-blue-400" };
    case 'demote_from_admin':
      return { Icon: ShieldOff, className: "w-4 h-4 text-orange-400" };
    case 'create_user_manually':
      return { Icon: UserPlus, className: "w-4 h-4 text-purple-400" };
    case 'delete_post':
      return { Icon: XCircle, className: "w-4 h-4 text-gray-400" };
    default:
      return { Icon: Activity, className: "w-4 h-4 text-blue-400" };
  }
};

export const getActionLabel = (action: string) => {
  switch (action) {
    case 'approve_user':
      return 'Usuário Aprovado';
    case 'reject_user':
      return 'Usuário Rejeitado';
    case 'promote_to_admin':
      return 'Promovido a Admin';
    case 'demote_from_admin':
      return 'Admin Removido';
    case 'create_user_manually':
      return 'Usuário Criado';
    case 'delete_post':
      return 'Post Excluído';
    default:
      return action;
  }
};
