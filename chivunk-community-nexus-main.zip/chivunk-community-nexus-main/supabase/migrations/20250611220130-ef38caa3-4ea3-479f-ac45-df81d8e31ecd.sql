
-- Criar tabela para notificações
CREATE TABLE public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  data JSONB DEFAULT NULL
);

-- Adicionar RLS para notificações
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Políticas para notificações (usuários só veem suas próprias)
CREATE POLICY "Users can view their own notifications" 
  ON public.notifications 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications" 
  ON public.notifications 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Função para criar notificações
CREATE OR REPLACE FUNCTION public.create_notification(
  target_user_id UUID,
  notification_type TEXT,
  notification_title TEXT,
  notification_message TEXT,
  notification_data JSONB DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  notification_id UUID;
BEGIN
  INSERT INTO public.notifications (user_id, type, title, message, data)
  VALUES (target_user_id, notification_type, notification_title, notification_message, notification_data)
  RETURNING id INTO notification_id;
  
  RETURN notification_id;
END;
$$;

-- Atualizar função de aprovação para incluir notificação
CREATE OR REPLACE FUNCTION public.approve_user(target_user_id uuid, admin_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Verificar se o usuário que executa é admin
  IF NOT public.is_admin(admin_user_id) THEN
    RAISE EXCEPTION 'Acesso negado: apenas administradores podem aprovar usuários';
  END IF;
  
  -- Aprovar usuário
  UPDATE public.profiles 
  SET 
    status = 'approved',
    approved_by = admin_user_id,
    approved_at = now()
  WHERE id = target_user_id;
  
  -- Criar notificação de aprovação
  PERFORM public.create_notification(
    target_user_id,
    'approval',
    'Conta Aprovada!',
    'Sua conta foi aprovada e você já pode acessar todos os recursos da comunidade.',
    jsonb_build_object('approved_by', admin_user_id)
  );
  
  -- Registrar log
  INSERT INTO public.admin_logs (admin_id, action, target_user_id, details)
  VALUES (admin_user_id, 'approve_user', target_user_id, '{"action": "User approved"}');
END;
$$;

-- Atualizar função de rejeição para incluir notificação
CREATE OR REPLACE FUNCTION public.reject_user(target_user_id uuid, admin_user_id uuid, reason text DEFAULT NULL::text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Verificar se o usuário que executa é admin
  IF NOT public.is_admin(admin_user_id) THEN
    RAISE EXCEPTION 'Acesso negado: apenas administradores podem rejeitar usuários';
  END IF;
  
  -- Rejeitar usuário
  UPDATE public.profiles 
  SET 
    status = 'rejected',
    approved_by = admin_user_id,
    approved_at = now(),
    rejection_reason = reason
  WHERE id = target_user_id;
  
  -- Criar notificação de rejeição
  PERFORM public.create_notification(
    target_user_id,
    'rejection',
    'Conta Rejeitada',
    COALESCE('Sua solicitação de acesso foi rejeitada. Motivo: ' || reason, 'Sua solicitação de acesso foi rejeitada.'),
    jsonb_build_object('rejected_by', admin_user_id, 'reason', reason)
  );
  
  -- Registrar log
  INSERT INTO public.admin_logs (admin_id, action, target_user_id, details)
  VALUES (admin_user_id, 'reject_user', target_user_id, jsonb_build_object('reason', reason));
END;
$$;

-- Função para promover usuário a admin
CREATE OR REPLACE FUNCTION public.promote_to_admin(target_user_id uuid, admin_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Verificar se o usuário que executa é admin
  IF NOT public.is_admin(admin_user_id) THEN
    RAISE EXCEPTION 'Acesso negado: apenas administradores podem promover usuários';
  END IF;
  
  -- Inserir role de admin (se não existir)
  INSERT INTO public.user_roles (user_id, role, assigned_by)
  VALUES (target_user_id, 'admin', admin_user_id)
  ON CONFLICT (user_id, role) DO NOTHING;
  
  -- Criar notificação
  PERFORM public.create_notification(
    target_user_id,
    'promotion',
    'Promovido a Administrador!',
    'Você foi promovido a administrador da comunidade. Agora você tem acesso ao painel administrativo.',
    jsonb_build_object('promoted_by', admin_user_id)
  );
  
  -- Registrar log
  INSERT INTO public.admin_logs (admin_id, action, target_user_id, details)
  VALUES (admin_user_id, 'promote_to_admin', target_user_id, '{"action": "User promoted to admin"}');
END;
$$;

-- Função para remover admin
CREATE OR REPLACE FUNCTION public.demote_from_admin(target_user_id uuid, admin_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Verificar se o usuário que executa é admin
  IF NOT public.is_admin(admin_user_id) THEN
    RAISE EXCEPTION 'Acesso negado: apenas administradores podem rebaixar usuários';
  END IF;
  
  -- Não permitir que admin remova a si mesmo
  IF target_user_id = admin_user_id THEN
    RAISE EXCEPTION 'Você não pode remover seus próprios privilégios de administrador';
  END IF;
  
  -- Remover role de admin
  DELETE FROM public.user_roles 
  WHERE user_id = target_user_id AND role = 'admin';
  
  -- Criar notificação
  PERFORM public.create_notification(
    target_user_id,
    'demotion',
    'Privilégios de Administrador Removidos',
    'Seus privilégios de administrador foram removidos.',
    jsonb_build_object('demoted_by', admin_user_id)
  );
  
  -- Registrar log
  INSERT INTO public.admin_logs (admin_id, action, target_user_id, details)
  VALUES (admin_user_id, 'demote_from_admin', target_user_id, '{"action": "Admin privileges removed"}');
END;
$$;

-- Função para criar usuário manualmente
CREATE OR REPLACE FUNCTION public.create_user_manually(
  user_email TEXT,
  user_name TEXT,
  user_password TEXT,
  admin_user_id UUID
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_user_id UUID;
BEGIN
  -- Verificar se o usuário que executa é admin
  IF NOT public.is_admin(admin_user_id) THEN
    RAISE EXCEPTION 'Acesso negado: apenas administradores podem criar usuários';
  END IF;
  
  -- Inserir usuário no auth.users (simulação - na prática seria via API)
  -- Por limitações do Supabase, vamos criar apenas o perfil e deixar o usuário se registrar
  new_user_id := gen_random_uuid();
  
  -- Criar perfil diretamente
  INSERT INTO public.profiles (id, name, status, approved_by, approved_at)
  VALUES (new_user_id, user_name, 'approved', admin_user_id, now());
  
  -- Registrar log
  INSERT INTO public.admin_logs (admin_id, action, target_user_id, details)
  VALUES (admin_user_id, 'create_user_manually', new_user_id, jsonb_build_object('email', user_email, 'name', user_name));
  
  RETURN new_user_id;
END;
$$;
