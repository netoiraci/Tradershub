
-- Função para promover o primeiro usuário a admin automaticamente
CREATE OR REPLACE FUNCTION public.auto_promote_first_admin()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  first_user_id UUID;
  admin_count INTEGER;
BEGIN
  -- Verificar se já existe algum admin
  SELECT COUNT(*) INTO admin_count 
  FROM public.user_roles 
  WHERE role = 'admin';
  
  -- Se não há admins, promover o primeiro usuário aprovado
  IF admin_count = 0 THEN
    SELECT id INTO first_user_id 
    FROM public.profiles 
    WHERE status = 'approved' 
    ORDER BY created_at ASC 
    LIMIT 1;
    
    -- Se encontrou um usuário, promovê-lo a admin
    IF first_user_id IS NOT NULL THEN
      INSERT INTO public.user_roles (user_id, role, assigned_by)
      VALUES (first_user_id, 'admin', first_user_id)
      ON CONFLICT (user_id, role) DO NOTHING;
      
      -- Criar notificação
      PERFORM public.create_notification(
        first_user_id,
        'promotion',
        'Você é o Administrador Principal!',
        'Parabéns! Como primeiro usuário da comunidade, você foi automaticamente promovido a administrador principal.',
        jsonb_build_object('auto_promoted', true)
      );
    END IF;
  END IF;
END;
$$;

-- Trigger para executar automaticamente quando um usuário for aprovado
CREATE OR REPLACE FUNCTION public.check_first_admin_trigger()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Executar apenas quando status muda para 'approved'
  IF OLD.status != 'approved' AND NEW.status = 'approved' THEN
    PERFORM public.auto_promote_first_admin();
  END IF;
  
  RETURN NEW;
END;
$$;

-- Criar o trigger
DROP TRIGGER IF EXISTS auto_promote_first_admin_trigger ON public.profiles;
CREATE TRIGGER auto_promote_first_admin_trigger
  AFTER UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.check_first_admin_trigger();

-- Executar uma vez para promover usuário existente (se houver)
SELECT public.auto_promote_first_admin();
