
-- 1. Permitir exclusão lógica de postagens (soft-delete) para manter histórico/timeline
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS deleted boolean NOT NULL DEFAULT false;

-- 2. Permitir exclusão lógica de comentários (manter histórico)
ALTER TABLE public.comments ADD COLUMN IF NOT EXISTS deleted boolean NOT NULL DEFAULT false;

-- 3. Implementar respostas a comentários (threaded comments, já existe parent_id, mas documentar uso)
-- (Nada a fazer no schema, mas recomenda-se ativar a foreign key, se necessário)

-- 4. Indexar para performance de timeline/histórico
CREATE INDEX IF NOT EXISTS idx_posts_created_at ON public.posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_comments_created_at ON public.comments(created_at DESC);

-- (Opcional) Foreign key para comments.parent_id
DO $$
BEGIN
    -- Verificar se a constraint já existe antes de criar
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE table_name='comments' AND constraint_type='FOREIGN KEY' AND constraint_name='fk_comments_parent_id'
    ) THEN
        ALTER TABLE public.comments
        ADD CONSTRAINT fk_comments_parent_id FOREIGN KEY (parent_id) REFERENCES public.comments(id) ON DELETE CASCADE;
    END IF;
END $$;

