
-- 1. Adicionar “reason” como campo opcional no JSONB de detalhes dos logs nas funções de promoção, remoção de admin e criação manual
-- 2. Alterar funções para aceitar um parâmetro opcional “reason” e registrar nos detalhes do log.
-- 3. Atualizar create_user_manually para receber e logar o reason.

-- ATUALIZAR FUNÇÃO: promote_to_admin
CREATE OR REPLACE FUNCTION public.promote_to_admin(target_user_id uuid, admin_user_id uuid, reason text DEFAULT NULL)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT public.is_admin(admin_user_id) THEN
    RAISE EXCEPTION 'Acesso negado: apenas administradores podem promover usuários';
  END IF;

  INSERT INTO public.user_roles (user_id, role, assigned_by)
  VALUES (target_user_id, 'admin', admin_user_id)
  ON CONFLICT (user_id, role) DO NOTHING;

  PERFORM public.create_notification(
    target_user_id,
    'promotion',
    'Promovido a Administrador!',
    'Você foi promovido a administrador da comunidade. Agora você tem acesso ao painel administrativo.',
    jsonb_build_object('promoted_by', admin_user_id)
  );

  INSERT INTO public.admin_logs (admin_id, action, target_user_id, details)
  VALUES (
    admin_user_id, 
    'promote_to_admin', 
    target_user_id, 
    jsonb_build_object('action', 'User promoted to admin', 'reason', reason)
  );
END;
$$;

-- ATUALIZAR FUNÇÃO: demote_from_admin
CREATE OR REPLACE FUNCTION public.demote_from_admin(target_user_id uuid, admin_user_id uuid, reason text DEFAULT NULL)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT public.is_admin(admin_user_id) THEN
    RAISE EXCEPTION 'Acesso negado: apenas administradores podem rebaixar usuários';
  END IF;

  IF target_user_id = admin_user_id THEN
    RAISE EXCEPTION 'Você não pode remover seus próprios privilégios de administrador';
  END IF;

  DELETE FROM public.user_roles 
  WHERE user_id = target_user_id AND role = 'admin';

  PERFORM public.create_notification(
    target_user_id,
    'demotion',
    'Privilégios de Administrador Removidos',
    'Seus privilégios de administrador foram removidos.',
    jsonb_build_object('demoted_by', admin_user_id)
  );

  INSERT INTO public.admin_logs (admin_id, action, target_user_id, details)
  VALUES (
    admin_user_id, 
    'demote_from_admin', 
    target_user_id, 
    jsonb_build_object('action', 'Admin privileges removed', 'reason', reason)
  );
END;
$$;

-- ATUALIZAR FUNÇÃO: create_user_manually
DROP FUNCTION IF EXISTS public.create_user_manually(text, text, text, uuid);

CREATE OR REPLACE FUNCTION public.create_user_manually(
  user_email TEXT,
  user_name TEXT,
  user_password TEXT,
  admin_user_id UUID,
  reason TEXT DEFAULT NULL
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_user_id UUID;
BEGIN
  IF NOT public.is_admin(admin_user_id) THEN
    RAISE EXCEPTION 'Acesso negado: apenas administradores podem criar usuários';
  END IF;

  new_user_id := gen_random_uuid();

  INSERT INTO public.profiles (id, name, status, approved_by, approved_at)
  VALUES (new_user_id, user_name, 'approved', admin_user_id, now());

  INSERT INTO public.admin_logs (admin_id, action, target_user_id, details)
  VALUES (
    admin_user_id, 
    'create_user_manually', 
    new_user_id, 
    jsonb_build_object('email', user_email, 'name', user_name, 'reason', reason)
  );

  RETURN new_user_id;
END;
$$;
