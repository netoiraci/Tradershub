
-- Criar tabela para salas de chat
CREATE TABLE public.chat_rooms (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  is_public BOOLEAN NOT NULL DEFAULT true,
  created_by UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela para mensagens do chat
CREATE TABLE public.chat_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES public.chat_rooms(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  content TEXT NOT NULL,
  message_type TEXT NOT NULL DEFAULT 'text',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  deleted BOOLEAN NOT NULL DEFAULT false
);

-- Criar tabela para participantes das salas
CREATE TABLE public.chat_participants (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES public.chat_rooms(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  joined_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_admin BOOLEAN NOT NULL DEFAULT false,
  UNIQUE(room_id, user_id)
);

-- Habilitar RLS
ALTER TABLE public.chat_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_participants ENABLE ROW LEVEL SECURITY;

-- Políticas para chat_rooms
CREATE POLICY "Users can view public rooms" 
  ON public.chat_rooms 
  FOR SELECT 
  USING (is_public = true OR created_by = auth.uid());

CREATE POLICY "Users can create rooms" 
  ON public.chat_rooms 
  FOR INSERT 
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Creators can update their rooms" 
  ON public.chat_rooms 
  FOR UPDATE 
  USING (auth.uid() = created_by);

-- Políticas para chat_messages
CREATE POLICY "Users can view messages from joined rooms" 
  ON public.chat_messages 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.chat_participants 
      WHERE room_id = chat_messages.room_id 
      AND user_id = auth.uid()
    )
    OR 
    EXISTS (
      SELECT 1 FROM public.chat_rooms 
      WHERE id = chat_messages.room_id 
      AND is_public = true
    )
  );

CREATE POLICY "Users can insert messages in joined rooms" 
  ON public.chat_messages 
  FOR INSERT 
  WITH CHECK (
    auth.uid() = user_id 
    AND (
      EXISTS (
        SELECT 1 FROM public.chat_participants 
        WHERE room_id = chat_messages.room_id 
        AND user_id = auth.uid()
      )
      OR 
      EXISTS (
        SELECT 1 FROM public.chat_rooms 
        WHERE id = chat_messages.room_id 
        AND is_public = true
      )
    )
  );

CREATE POLICY "Users can update their own messages" 
  ON public.chat_messages 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Políticas para chat_participants
CREATE POLICY "Users can view participants of joined rooms" 
  ON public.chat_participants 
  FOR SELECT 
  USING (
    user_id = auth.uid() 
    OR 
    EXISTS (
      SELECT 1 FROM public.chat_participants cp 
      WHERE cp.room_id = chat_participants.room_id 
      AND cp.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can join public rooms" 
  ON public.chat_participants 
  FOR INSERT 
  WITH CHECK (
    auth.uid() = user_id 
    AND 
    EXISTS (
      SELECT 1 FROM public.chat_rooms 
      WHERE id = room_id 
      AND is_public = true
    )
  );

-- Habilitar realtime para as tabelas de chat
ALTER TABLE public.chat_rooms REPLICA IDENTITY FULL;
ALTER TABLE public.chat_messages REPLICA IDENTITY FULL;
ALTER TABLE public.chat_participants REPLICA IDENTITY FULL;

-- Adicionar tabelas à publicação realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_rooms;
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_participants;

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para atualizar updated_at
CREATE TRIGGER update_chat_rooms_updated_at 
  BEFORE UPDATE ON public.chat_rooms 
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_chat_messages_updated_at 
  BEFORE UPDATE ON public.chat_messages 
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Criar sala de chat geral padrão
INSERT INTO public.chat_rooms (name, description, is_public, created_by)
VALUES (
  'Chat Geral',
  'Sala de chat geral da comunidade de trading',
  true,
  (SELECT id FROM public.profiles WHERE status = 'approved' ORDER BY created_at ASC LIMIT 1)
);
