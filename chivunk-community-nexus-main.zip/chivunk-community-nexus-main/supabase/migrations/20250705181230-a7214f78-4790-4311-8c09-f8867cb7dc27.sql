-- Criar usuário de teste e dados de exemplo para a comunidade de trading

-- 1. Inserir perfil de usuário de teste (ajustando experience_level)
INSERT INTO public.profiles (
  id, 
  name, 
  status, 
  bio, 
  experience_level, 
  trading_goals,
  created_at,
  approved_at,
  approved_by
) VALUES (
  'a0000000-0000-0000-0000-000000000001',
  'Usuário de Teste',
  'approved',
  'Perfil de teste para demonstração da plataforma. Trader experiente em análise técnica e day trade.',
  'advanced',
  'Compartilhar conhecimento e ajudar novos traders',
  now(),
  now(),
  'a0000000-0000-0000-0000-000000000001'
);

-- 2. Criar role de admin para o usuário de teste
INSERT INTO public.user_roles (user_id, role, assigned_by, assigned_at)
VALUES ('a0000000-0000-0000-0000-000000000001', 'admin', 'a0000000-0000-0000-0000-000000000001', now())
ON CONFLICT (user_id, role) DO NOTHING;

-- 3. Criar salas de chat temáticas
INSERT INTO public.chat_rooms (id, name, description, is_public, created_by) VALUES
('room-analise-tecnica', 'Análise Técnica', 'Discussões sobre análise técnica, padrões gráficos e indicadores', true, 'a0000000-0000-0000-0000-000000000001'),
('room-day-trade', 'Day Trade', 'Estratégias e discussões sobre operações intraday', true, 'a0000000-0000-0000-0000-000000000001'),
('room-swing-trade', 'Swing Trade', 'Operações de médio prazo e análise fundamentalista', true, 'a0000000-0000-0000-0000-000000000001'),
('room-criptomoedas', 'Criptomoedas', 'Discussões sobre Bitcoin, Ethereum e outras criptomoedas', true, 'a0000000-0000-0000-0000-000000000001'),
('room-acoes-br', 'Ações Brasil', 'Análise de ações da bolsa brasileira (B3)', true, 'a0000000-0000-0000-0000-000000000001');

-- 4. Criar posts de exemplo diversificados
INSERT INTO public.posts (id, user_id, title, content, section, category, created_at) VALUES
('post-001', 'a0000000-0000-0000-0000-000000000001', 'Análise do IBOV para a próxima semana', 
'Pessoal, analisando o gráfico do Ibovespa, vejo uma possível reversão na região dos 125.000 pontos. O que vocês acham?

📊 Pontos importantes:
- RSI em região de sobrevenda
- Suporte histórico sendo testado
- Volume baixo nas últimas sessões

Aguardo opiniões!', 'feed', 'Análise Técnica', now() - interval '2 hours'),

('post-002', 'a0000000-0000-0000-0000-000000000001', 'Estratégia de Day Trade que tem funcionado',
'Compartilhando uma estratégia simples que tenho usado:

🎯 Setup:
1. Identificar tendência no gráfico de 15min
2. Aguardar pullback no gráfico de 5min
3. Entrada na confirmação com stop apertado

📈 Resultados:
- 70% de acertos nas últimas 20 operações
- Risk:Reward de 1:2

Quem já testou algo similar?', 'feed', 'Day Trade', now() - interval '5 hours'),

('post-003', 'a0000000-0000-0000-0000-000000000001', 'Bitcoin: Momento de acumulação?',
'O BTC está em uma fase interessante. Depois da correção dos últimos meses, pode ser um bom momento para começar a acumular?

💰 Cenário atual:
- Preço próximo a suportes importantes
- Whales acumulando conforme dados on-chain
- Mercado em fase de medo extremo

Vocês estão comprando ou aguardando mais queda?', 'feed', 'Criptomoedas', now() - interval '1 day'),

('post-004', 'a0000000-0000-0000-0000-000000000001', 'Gestão de risco: A base do sucesso no trading',
'Não importa quão boa seja sua análise, sem gestão de risco adequada, você vai perder dinheiro.

⚠️ Regras que sigo:
1. Nunca arrisco mais que 2% da conta por trade
2. Stop loss SEMPRE definido antes da entrada
3. Position sizing baseado na volatilidade do ativo
4. Diversificação entre diferentes setores

📚 Livros recomendados:
- "Trading in the Zone" - Mark Douglas
- "Market Wizards" - Jack Schwager

Qual sua regra de ouro para gestão de risco?', 'feed', 'Educação', now() - interval '8 hours');

-- 5. Criar mensagens de exemplo nas salas de chat
INSERT INTO public.chat_messages (id, room_id, user_id, content, message_type, created_at) VALUES
('msg-001', 'room-analise-tecnica', 'a0000000-0000-0000-0000-000000000001', 'Boa tarde pessoal! Alguém está acompanhando o PETR4 hoje?', 'text', now() - interval '30 minutes'),
('msg-002', 'room-analise-tecnica', 'a0000000-0000-0000-0000-000000000001', 'Vejo uma possível formação de ombro-cabeça-ombro no gráfico diário', 'text', now() - interval '25 minutes'),
('msg-003', 'room-day-trade', 'a0000000-0000-0000-0000-000000000001', 'Mercado bem lateral hoje, difícil para day trade', 'text', now() - interval '20 minutes'),
('msg-004', 'room-day-trade', 'a0000000-0000-0000-0000-000000000001', 'Aguardando o break dos 125k no IBOV para definir a direção', 'text', now() - interval '15 minutes'),
('msg-005', 'room-criptomoedas', 'a0000000-0000-0000-0000-000000000001', 'BTC testando suporte importante nos $42k', 'text', now() - interval '10 minutes'),
('msg-006', 'room-swing-trade', 'a0000000-0000-0000-0000-000000000001', 'Procurando setups de swing trade para as próximas semanas', 'text', now() - interval '5 minutes');

-- 6. Criar comentários de exemplo
INSERT INTO public.comments (id, post_id, author_id, content, created_at) VALUES
('comment-001', 'post-001', 'a0000000-0000-0000-0000-000000000001', 'Concordo com a análise! Também vejo o RSI em sobrevenda. Pode ser um bom ponto de entrada para swing trade.', now() - interval '1 hour'),
('comment-002', 'post-002', 'a0000000-0000-0000-0000-000000000001', 'Estratégia interessante! Você usa algum indicador específico para confirmar o pullback?', now() - interval '3 hours'),
('comment-003', 'post-003', 'a0000000-0000-0000-0000-000000000001', 'Estou aguardando o BTC chegar nos $40k para começar a acumular. Acho que ainda pode cair mais um pouco.', now() - interval '12 hours'),
('comment-004', 'post-004', 'a0000000-0000-0000-0000-000000000001', 'Excelente post! Gestão de risco é realmente fundamental. Também sigo a regra dos 2% por trade.', now() - interval '6 hours');

-- 7. Criar alguns likes nos posts
INSERT INTO public.post_likes (post_id, user_id, created_at) VALUES
('post-001', 'a0000000-0000-0000-0000-000000000001', now() - interval '30 minutes'),
('post-002', 'a0000000-0000-0000-0000-000000000001', now() - interval '2 hours'),
('post-003', 'a0000000-0000-0000-0000-000000000001', now() - interval '10 hours'),
('post-004', 'a0000000-0000-0000-0000-000000000001', now() - interval '4 hours');

-- 8. Criar notificação de boas-vindas
INSERT INTO public.notifications (user_id, type, title, message, created_at) VALUES
('a0000000-0000-0000-0000-000000000001', 'welcome', 'Bem-vindo à Comunidade!', 'Sua conta foi criada com sucesso. Explore as salas de chat e participe das discussões!', now() - interval '1 day');

-- 9. Atualizar contadores dos posts
UPDATE public.posts SET 
  likes_count = 1,
  comments_count = 1
WHERE id IN ('post-001', 'post-002', 'post-003', 'post-004');