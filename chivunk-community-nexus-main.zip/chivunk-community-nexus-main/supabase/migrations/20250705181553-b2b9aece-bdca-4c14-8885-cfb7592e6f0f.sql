-- Criar dados de teste básicos para a comunidade de trading

-- 1. Inserir perfil de usuário de teste (sem campos com constraints)
INSERT INTO public.profiles (
  id, 
  name, 
  status, 
  bio,
  created_at,
  approved_at,
  approved_by
) VALUES (
  'a0000000-0000-0000-0000-000000000001',
  'Usuário de Teste',
  'approved',
  'Perfil de teste para demonstração da plataforma. Trader experiente em análise técnica e day trade.',
  now(),
  now(),
  'a0000000-0000-0000-0000-000000000001'
);

-- 2. Criar role de admin para o usuário de teste
INSERT INTO public.user_roles (user_id, role, assigned_by, assigned_at)
VALUES ('a0000000-0000-0000-0000-000000000001', 'admin', 'a0000000-0000-0000-0000-000000000001', now())
ON CONFLICT (user_id, role) DO NOTHING;

-- 3. Criar salas de chat temáticas
INSERT INTO public.chat_rooms (id, name, description, is_public, created_by) VALUES
('room-analise-tecnica', 'Análise Técnica', 'Discussões sobre análise técnica, padrões gráficos e indicadores', true, 'a0000000-0000-0000-0000-000000000001'),
('room-day-trade', 'Day Trade', 'Estratégias e discussões sobre operações intraday', true, 'a0000000-0000-0000-0000-000000000001'),
('room-swing-trade', 'Swing Trade', 'Operações de médio prazo e análise fundamentalista', true, 'a0000000-0000-0000-0000-000000000001'),
('room-criptomoedas', 'Criptomoedas', 'Discussões sobre Bitcoin, Ethereum e outras criptomoedas', true, 'a0000000-0000-0000-0000-000000000001'),
('room-acoes-br', 'Ações Brasil', 'Análise de ações da bolsa brasileira (B3)', true, 'a0000000-0000-0000-0000-000000000001');

-- 4. Criar posts de exemplo diversificados
INSERT INTO public.posts (id, user_id, title, content, section, category, created_at) VALUES
('post-001', 'a0000000-0000-0000-0000-000000000001', 'Análise do IBOV para a próxima semana', 
'Pessoal, analisando o gráfico do Ibovespa, vejo uma possível reversão na região dos 125.000 pontos. O que vocês acham?

📊 Pontos importantes:
- RSI em região de sobrevenda
- Suporte histórico sendo testado
- Volume baixo nas últimas sessões

Aguardo opiniões!', 'feed', 'Análise Técnica', now() - interval '2 hours'),

('post-002', 'a0000000-0000-0000-0000-000000000001', 'Estratégia de Day Trade que tem funcionado',
'Compartilhando uma estratégia simples que tenho usado:

🎯 Setup:
1. Identificar tendência no gráfico de 15min
2. Aguardar pullback no gráfico de 5min
3. Entrada na confirmação com stop apertado

📈 Resultados:
- 70% de acertos nas últimas 20 operações
- Risk:Reward de 1:2

Quem já testou algo similar?', 'feed', 'Day Trade', now() - interval '5 hours'),

('post-003', 'a0000000-0000-0000-0000-000000000001', 'Bitcoin: Momento de acumulação?',
'O BTC está em uma fase interessante. Depois da correção dos últimos meses, pode ser um bom momento para começar a acumular?

💰 Cenário atual:
- Preço próximo a suportes importantes
- Whales acumulando conforme dados on-chain
- Mercado em fase de medo extremo

Vocês estão comprando ou aguardando mais queda?', 'feed', 'Criptomoedas', now() - interval '1 day'),

('post-004', 'a0000000-0000-0000-0000-000000000001', 'Gestão de risco: A base do sucesso no trading',
'Não importa quão boa seja sua análise, sem gestão de risco adequada, você vai perder dinheiro.

⚠️ Regras que sigo:
1. Nunca arrisco mais que 2% da conta por trade
2. Stop loss SEMPRE definido antes da entrada
3. Position sizing baseado na volatilidade do ativo
4. Diversificação entre diferentes setores

📚 Livros recomendados:
- "Trading in the Zone" - Mark Douglas
- "Market Wizards" - Jack Schwager

Qual sua regra de ouro para gestão de risco?', 'feed', 'Educação', now() - interval '8 hours');