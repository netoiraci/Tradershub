-- Criar salas de chat e conteúdo básico para testes

-- 1. Criar salas de chat temáticas (não dependem de usuários específicos)
INSERT INTO public.chat_rooms (id, name, description, is_public, created_by) 
SELECT 
  'room-geral' as id,
  'Geral' as name,
  'Discussões gerais sobre trading e mercado financeiro' as description,
  true as is_public,
  auth.uid() as created_by
WHERE auth.uid() IS NOT NULL
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.chat_rooms (id, name, description, is_public, created_by) 
SELECT 
  'room-analise-tecnica' as id,
  'Análise Técnica' as name,
  'Discussões sobre análise técnica, padrões gráficos e indicadores' as description,
  true as is_public,
  auth.uid() as created_by
WHERE auth.uid() IS NOT NULL
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.chat_rooms (id, name, description, is_public, created_by) 
SELECT 
  'room-day-trade' as id,
  'Day Trade' as name,
  'Estratégias e discussões sobre operações intraday' as description,
  true as is_public,
  auth.uid() as created_by
WHERE auth.uid() IS NOT NULL
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.chat_rooms (id, name, description, is_public, created_by) 
SELECT 
  'room-swing-trade' as id,
  'Swing Trade' as name,
  'Operações de médio prazo e análise fundamentalista' as description,
  true as is_public,
  auth.uid() as created_by
WHERE auth.uid() IS NOT NULL
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.chat_rooms (id, name, description, is_public, created_by) 
SELECT 
  'room-criptomoedas' as id,
  'Criptomoedas' as name,
  'Discussões sobre Bitcoin, Ethereum e outras criptomoedas' as description,
  true as is_public,
  auth.uid() as created_by
WHERE auth.uid() IS NOT NULL
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.chat_rooms (id, name, description, is_public, created_by) 
SELECT 
  'room-acoes-br' as id,
  'Ações Brasil' as name,
  'Análise de ações da bolsa brasileira (B3)' as description,
  true as is_public,
  auth.uid() as created_by
WHERE auth.uid() IS NOT NULL
ON CONFLICT (id) DO NOTHING;