-- Criar salas de chat temáticas com UUIDs válidos
INSERT INTO public.chat_rooms (name, description, is_public, created_by) 
SELECT 
  'Geral' as name,
  'Discussões gerais sobre trading e mercado financeiro' as description,
  true as is_public,
  (SELECT id FROM profiles WHERE status = 'approved' ORDER BY created_at ASC LIMIT 1) as created_by
WHERE EXISTS (SELECT 1 FROM profiles WHERE status = 'approved')
ON CONFLICT DO NOTHING;

INSERT INTO public.chat_rooms (name, description, is_public, created_by) 
SELECT 
  'Análise Técnica' as name,
  'Discussões sobre análise técnica, padrões gráficos e indicadores' as description,
  true as is_public,
  (SELECT id FROM profiles WHERE status = 'approved' ORDER BY created_at ASC LIMIT 1) as created_by
WHERE EXISTS (SELECT 1 FROM profiles WHERE status = 'approved')
ON CONFLICT DO NOTHING;

INSERT INTO public.chat_rooms (name, description, is_public, created_by) 
SELECT 
  'Day Trade' as name,
  'Estratégias e discussões sobre operações intraday' as description,
  true as is_public,
  (SELECT id FROM profiles WHERE status = 'approved' ORDER BY created_at ASC LIMIT 1) as created_by
WHERE EXISTS (SELECT 1 FROM profiles WHERE status = 'approved')
ON CONFLICT DO NOTHING;

INSERT INTO public.chat_rooms (name, description, is_public, created_by) 
SELECT 
  'Swing Trade' as name,
  'Operações de médio prazo e análise fundamentalista' as description,
  true as is_public,
  (SELECT id FROM profiles WHERE status = 'approved' ORDER BY created_at ASC LIMIT 1) as created_by
WHERE EXISTS (SELECT 1 FROM profiles WHERE status = 'approved')
ON CONFLICT DO NOTHING;

INSERT INTO public.chat_rooms (name, description, is_public, created_by) 
SELECT 
  'Criptomoedas' as name,
  'Discussões sobre Bitcoin, Ethereum e outras criptomoedas' as description,
  true as is_public,
  (SELECT id FROM profiles WHERE status = 'approved' ORDER BY created_at ASC LIMIT 1) as created_by
WHERE EXISTS (SELECT 1 FROM profiles WHERE status = 'approved')
ON CONFLICT DO NOTHING;

INSERT INTO public.chat_rooms (name, description, is_public, created_by) 
SELECT 
  'Ações Brasil' as name,
  'Análise de ações da bolsa brasileira (B3)' as description,
  true as is_public,
  (SELECT id FROM profiles WHERE status = 'approved' ORDER BY created_at ASC LIMIT 1) as created_by
WHERE EXISTS (SELECT 1 FROM profiles WHERE status = 'approved')
ON CONFLICT DO NOTHING;