-- Função para auto-aprovar novos usuários e promover o primeiro como admin
CREATE OR REPLACE FUNCTION public.auto_approve_new_users()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Auto-aprovar o usuário
  NEW.status = 'approved';
  NEW.approved_at = now();
  NEW.approved_by = NEW.id; -- auto-aprovação
  
  -- Verificar se é o primeiro usuário e promover a admin
  PERFORM public.auto_promote_first_admin();
  
  RETURN NEW;
END;
$$;

-- Criar trigger para auto-aprovar novos usuários
DROP TRIGGER IF EXISTS auto_approve_users_trigger ON public.profiles;
CREATE TRIGGER auto_approve_users_trigger
  BEFORE INSERT ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_approve_new_users();

-- Melhorar a função de promoção do primeiro admin
CREATE OR REPLACE FUNCTION public.auto_promote_first_admin()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  first_user_id UUID;
  admin_count INTEGER;
BEGIN
  -- Verificar se já existe algum admin
  SELECT COUNT(*) INTO admin_count 
  FROM public.user_roles 
  WHERE role = 'admin';
  
  -- Se não há admins, promover o primeiro usuário aprovado
  IF admin_count = 0 THEN
    SELECT id INTO first_user_id 
    FROM public.profiles 
    WHERE status = 'approved' 
    ORDER BY created_at ASC 
    LIMIT 1;
    
    -- Se encontrou um usuário, promovê-lo a admin
    IF first_user_id IS NOT NULL THEN
      INSERT INTO public.user_roles (user_id, role, assigned_by)
      VALUES (first_user_id, 'admin', first_user_id)
      ON CONFLICT (user_id, role) DO NOTHING;
      
      -- Criar notificação de promoção
      PERFORM public.create_notification(
        first_user_id,
        'promotion',
        'Você é o Administrador Principal!',
        'Parabéns! Como primeiro usuário da comunidade, você foi automaticamente promovido a administrador principal. Acesse o painel admin para gerenciar a comunidade.',
        jsonb_build_object('auto_promoted', true, 'first_admin', true)
      );
    END IF;
  END IF;
END;
$$;