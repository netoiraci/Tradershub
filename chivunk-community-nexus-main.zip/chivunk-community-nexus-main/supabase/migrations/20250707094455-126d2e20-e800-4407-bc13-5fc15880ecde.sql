-- Fix infinite recursion in chat_participants RLS policies

-- First, drop the problematic policy
DROP POLICY IF EXISTS "Users can view participants of joined rooms" ON public.chat_participants;

-- Create a security definer function to check if user is participant of a room
CREATE OR REPLACE FUNCTION public.is_room_participant(room_uuid uuid, user_uuid uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.chat_participants 
    WHERE room_id = room_uuid AND user_id = user_uuid
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- Create a better SELECT policy that doesn't cause infinite recursion
CREATE POLICY "Users can view participants of rooms they joined or public rooms" 
ON public.chat_participants 
FOR SELECT 
USING (
  -- User can see participants of public rooms
  EXISTS (
    SELECT 1 FROM public.chat_rooms 
    WHERE id = chat_participants.room_id AND is_public = true
  )
  OR
  -- User can see participants of rooms they are in (using security definer function)
  public.is_room_participant(chat_participants.room_id, auth.uid())
);

-- Also update the INSERT policy to be more robust
DROP POLICY IF EXISTS "Users can join public rooms" ON public.chat_participants;

CREATE POLICY "Users can join public rooms" 
ON public.chat_participants 
FOR INSERT 
WITH CHECK (
  auth.uid() = user_id 
  AND EXISTS (
    SELECT 1 FROM public.chat_rooms 
    WHERE id = chat_participants.room_id AND is_public = true
  )
);

-- Add DELETE policy so users can leave rooms
CREATE POLICY "Users can leave rooms" 
ON public.chat_participants 
FOR DELETE 
USING (auth.uid() = user_id);

-- Enable RLS on the table (just to be sure)
ALTER TABLE public.chat_participants ENABLE ROW LEVEL SECURITY;