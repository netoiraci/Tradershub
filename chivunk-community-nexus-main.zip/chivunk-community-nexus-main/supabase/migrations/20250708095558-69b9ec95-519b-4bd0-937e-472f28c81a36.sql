-- Fix user presence to have proper unique constraint
-- First drop existing constraint if any
DROP INDEX IF EXISTS user_presence_user_room_unique;

-- Add a proper unique constraint on user_id and room_id combination
-- This ensures each user can only have one presence record per room (or global)
CREATE UNIQUE INDEX user_presence_user_room_unique 
ON public.user_presence (user_id, COALESCE(room_id, '00000000-0000-0000-0000-000000000000'::uuid));

-- Add a function to clean up old presence records
CREATE OR REPLACE FUNCTION public.cleanup_old_presence()
RETURNS void AS $$
BEGIN
  -- Delete presence records older than 10 minutes
  DELETE FROM public.user_presence 
  WHERE last_seen < NOW() - INTERVAL '10 minutes';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;